import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  allowedDevOrigins: [
    "preview-chat-2b9e6795-479d-456c-8463-293b1c7cbbb4.space-z.ai",
    "127.0.0.1",
    "localhost",
  ],
};

export default nextConfig;
