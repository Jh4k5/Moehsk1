'use client'

import React, { useState, useCallback, useMemo, useEffect } from 'react'
import { useSession, signOut } from 'next-auth/react'
import { vocabulary } from '@/data/vocabulary'
import { useLearningStore } from '@/lib/store'
import type { Section } from '@/types'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { motion, AnimatePresence } from 'framer-motion'
import {
  BookOpen, GraduationCap, Gamepad2, BookMarked, Map, LayoutDashboard,
  Flame, Star, Target, Sparkles, Bot,
  PenTool, FileText, Medal, Image, HelpCircle, BookOpenText,
  MessageSquare, MessageCircle, Menu, X, ChevronLeft, Mic, LogIn, LogOut,
  Volume2, Cloud, CloudOff
} from 'lucide-react'
import dynamic from 'next/dynamic'

// ─── Lazy loaded components ──────────────────────────────────
const DashboardWidgets = dynamic(() => import('@/components/DashboardWidgets'), { ssr: false })
const VocabularySection = dynamic(() => import('@/components/sections/VocabularySection'), { ssr: false })
const GrammarSection = dynamic(() => import('@/components/sections/GrammarSection'), { ssr: false })
const PracticeSection = dynamic(() => import('@/components/sections/PracticeSection'), { ssr: false })
const GamesSection = dynamic(() => import('@/components/sections/GamesSection'), { ssr: false })
const SentencesSection = dynamic(() => import('@/components/sections/SentencesSection'), { ssr: false })
const StoriesSection = dynamic(() => import('@/components/sections/StoriesSection'), { ssr: false })
const ChatSection = dynamic(() => import('@/components/sections/ChatSection'), { ssr: false })
const RoadmapSection = dynamic(() => import('@/components/sections/RoadmapSection'), { ssr: false })
const PinyinHub = dynamic(() => import('@/components/PinyinHub'), { ssr: false })
const HanziSection = dynamic(() => import('@/components/HanziSection'), { ssr: false })
const ExamSimulator = dynamic(() => import('@/components/ExamSimulator'), { ssr: false })
const ConversationsSection = dynamic(() => import('@/components/ConversationsSection'), { ssr: false })
const LessonSystem = dynamic(() => import('@/components/LessonSystem'), { ssr: false })
const ConversationPracticeSection = dynamic(() => import('@/components/ConversationPracticeSection'), { ssr: false })
const VisualDictionary = dynamic(() => import('@/components/VisualDictionary'), { ssr: false })
const AchievementsSection = dynamic(() => import('@/components/AchievementsSection'), { ssr: false })
const AuthDialog = dynamic(() => import('@/components/AuthDialog'), { ssr: false })

// ─── Sidebar Nav Items ───────────────────────────────────────
const sidebarSections: { id: Section; label: string; icon: React.FC<{ className?: string }> }[] = [
  { id: 'pronunciation', label: 'تمارين النطق', icon: Mic },
  { id: 'lessons', label: 'الدروس', icon: BookOpenText },
  { id: 'vocabulary', label: 'المفردات والنطق', icon: BookOpen },
  { id: 'grammar', label: 'القواعد', icon: GraduationCap },
  { id: 'conversations', label: 'المحادثات', icon: MessageSquare },
  { id: 'sentences', label: 'الجمل', icon: MessageCircle },
  { id: 'practice', label: 'التمارين', icon: Target },
  { id: 'games', label: 'الألعاب', icon: Gamepad2 },
  { id: 'pinyin', label: 'البينين', icon: Sparkles },
  { id: 'hanzi', label: 'الحروف', icon: PenTool },
  { id: 'visual-dict', label: 'القاموس البصري', icon: Image },
  { id: 'stories', label: 'القصص', icon: BookMarked },
  { id: 'exam', label: 'محاكي الامتحان', icon: FileText },
  { id: 'achievements', label: 'الإنجازات', icon: Medal },
  { id: 'chat', label: 'المساعد الذكي', icon: Bot },
  { id: 'conversation-practice', label: 'تمارين المحادثة', icon: HelpCircle },
  { id: 'roadmap', label: 'خريطة الطريق', icon: Map },
]

export default function Home() {
  const { data: session, status: authStatus } = useSession()
  const [activeSection, setActiveSection] = useState<Section | null>(null)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [authOpen, setAuthOpen] = useState(false)
  const store = useLearningStore()

  const isAuthenticated = authStatus === 'authenticated'
  const userName = session?.user?.name || session?.user?.email || ''

  // Sync store isLoggedIn flag with actual auth state
  useEffect(() => {
    store.setIsLoggedIn(isAuthenticated)
  }, [isAuthenticated, store.setIsLoggedIn])

  // Force auth dialog open when user is not authenticated
  useEffect(() => {
    if (authStatus === 'unauthenticated') {
      setAuthOpen(true)
    }
  }, [authStatus])

  // On login: fetch server data and merge
  useEffect(() => {
    if (isAuthenticated) {
      setAuthOpen(false)
      store.syncFromServer()
    }
  }, [isAuthenticated])

  // Handle logout
  const handleLogout = useCallback(async () => {
    await signOut({ redirect: false })
    store.setIsLoggedIn(false)
  }, [store.setIsLoggedIn])

  // Stats
  const stats = useMemo(() => {
    const total = vocabulary.length
    const learned = store.learnedWords.length
    const progress = total > 0 ? Math.round((learned / total) * 100) : 0
    return { total, learned, progress }
  }, [store.learnedWords])

  const navigateToSection = useCallback((section: Section) => {
    setActiveSection(section)
    setSidebarOpen(false)
  }, [])

  const goBack = useCallback(() => {
    setActiveSection(null)
  }, [])

  // Close sidebar on escape
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (sidebarOpen) setSidebarOpen(false)
        else if (activeSection) setActiveSection(null)
      }
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [sidebarOpen, activeSection])

  // ─── Render active section content ──────────────────────────
  const renderSectionContent = () => {
    if (!activeSection) return null
    switch (activeSection) {
      case 'vocabulary': return <VocabularySection />
      case 'grammar': return <GrammarSection />
      case 'practice': return <PracticeSection quizAnswer={null} setQuizAnswer={() => {}} quizFinished={false} setQuizFinished={() => {}} generateQuiz={() => {}} quizDifficulty={'medium'} setQuizDifficulty={() => {}} hardTimer={15} setHardTimer={() => {}} />
      case 'games': return <GamesSection memoryFlipped={[]} handleMemoryClick={() => {}} startMemoryGame={() => {}} toneAnswer={null} setToneAnswer={() => {}} toneScore={0} setToneScore={() => {}} toneRound={0} setToneRound={() => {}} />
      case 'sentences': return <SentencesSection sentenceFlipped={false} setSentenceFlipped={() => {}} sentenceIndex={0} setSentenceIndex={() => {}} />
      case 'stories': return <StoriesSection activeStory={0} setActiveStory={() => {}} storyAnswers={{}} setStoryAnswers={() => {}} />
      case 'chat': return <ChatSection />
      case 'roadmap': return <RoadmapSection onNavigate={navigateToSection} />
      case 'pinyin': return <PinyinHub />
      case 'hanzi': return <HanziSection />
      case 'exam': return <ExamSimulator />
      case 'conversations': return <ConversationsSection />
      case 'lessons': return <LessonSystem />
      case 'conversation-practice': return <ConversationPracticeSection />
      case 'visual-dict': return <VisualDictionary />
      case 'achievements': return <AchievementsSection />
      case 'pronunciation': {
        // Lazy import pronunciation
        const PronunciationPractice = dynamic(() => import('@/components/PronunciationPractice'), { ssr: false })
        return <PronunciationPractice />
      }
      default: return <div className="text-center py-12 text-gray-500">قسم غير معرف</div>
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-50/50" dir="rtl">
      {/* ─── Header ──────────────────────────────────────────── */}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-gray-100 shadow-sm">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {/* Sidebar Toggle */}
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden w-10 h-10 rounded-xl bg-gray-100 flex items-center justify-center hover:bg-gray-200 transition-colors"
              aria-label="فتح القائمة"
            >
              <Menu className="w-5 h-5 text-gray-700" />
            </button>
            {/* Logo */}
            <button
              onClick={goBack}
              className="flex items-center gap-3 hover:opacity-80 transition-opacity"
            >
              <div className="w-10 h-10 rounded-xl bg-[#1CB0F6] flex items-center justify-center shadow-sm" style={{ borderBottom: '3px solid #0A90D4' }}>
                <span className="font-chinese-serif text-white text-xl font-bold">汉</span>
              </div>
              <div className="hidden sm:block">
                <h1 className="text-lg font-bold text-gray-900">مُضَّن — تعلم الصينية</h1>
                <p className="text-xs text-gray-500">{stats.total} كلمة • HSK 1</p>
              </div>
            </button>
          </div>

          <div className="flex items-center gap-2">
            {/* Streak Badge */}
            <Badge className="hidden sm:flex gap-1 bg-amber-50 text-amber-700 border-amber-200">
              <Flame className="w-3 h-3 text-amber-500" />
              <span>{store.dailyStreak} يوم</span>
            </Badge>
            {/* Progress Badge */}
            <Badge className="hidden sm:flex gap-1 bg-emerald-50 text-emerald-700 border-emerald-200">
              <Star className="w-3 h-3 text-emerald-500" />
              <span>{stats.learned}/{stats.total}</span>
            </Badge>
            {/* Auth Button: Login or User Menu */}
            {isAuthenticated ? (
              <div className="flex items-center gap-2">
                {store.isSyncing ? (
                  <Cloud className="w-4 h-4 text-blue-400 animate-pulse" />
                ) : store.lastSyncedAt ? (
                  <Cloud className="w-4 h-4 text-emerald-400" />
                ) : (
                  <CloudOff className="w-4 h-4 text-gray-300" />
                )}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleLogout}
                  className="gap-1 text-gray-600 hover:text-red-600"
                >
                  <LogOut className="w-4 h-4" />
                  <span className="hidden sm:inline max-w-[120px] truncate">{userName}</span>
                </Button>
              </div>
            ) : (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setAuthOpen(true)}
                className="gap-1 text-gray-600 hover:text-red-600"
              >
                <LogIn className="w-4 h-4" />
                <span className="hidden sm:inline">تسجيل الدخول</span>
              </Button>
            )}
            {/* Desktop Sidebar Toggle */}
            <button
              onClick={() => setSidebarOpen(true)}
              className="hidden lg:flex w-10 h-10 rounded-xl bg-gray-100 items-center justify-center hover:bg-gray-200 transition-colors"
              aria-label="فتح القائمة الجانبية"
            >
              <Menu className="w-5 h-5 text-gray-700" />
            </button>
          </div>
        </div>
      </header>

      {/* ─── Main Content ────────────────────────────────────── */}
      <main className="flex-1">
        <AnimatePresence mode="wait">
          {activeSection ? (
            // Section View
            <motion.div
              key={activeSection}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.2 }}
              className="max-w-6xl mx-auto px-4 py-4 md:py-6 pb-24 lg:pb-6"
            >
              {/* Section Header with Back Button */}
              <div className="flex items-center gap-3 mb-6">
                <button
                  onClick={goBack}
                  className="w-10 h-10 rounded-xl bg-white border border-gray-200 flex items-center justify-center hover:bg-gray-50 transition-colors shadow-sm"
                >
                  <ChevronLeft className="w-5 h-5 text-gray-600" />
                </button>
                <div>
                  <h2 className="text-xl font-bold text-gray-900">
                    {sidebarSections.find(s => s.id === activeSection)?.label || ''}
                  </h2>
                  <Progress value={stats.progress} className="h-1.5 w-32 mt-1" />
                </div>
              </div>

              {/* Section Content */}
              <div key={activeSection}>
                {renderSectionContent()}
              </div>
            </motion.div>
          ) : (
            // Dashboard View
            <motion.div
              key="dashboard"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="max-w-6xl mx-auto px-4 py-4 md:py-6 pb-24 lg:pb-6"
            >
              <DashboardWidgets onNavigate={navigateToSection} />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* ─── Sidebar Overlay ─────────────────────────────────── */}
      <AnimatePresence>
        {sidebarOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSidebarOpen(false)}
              className="fixed inset-0 z-50 bg-black/30 backdrop-blur-sm"
            />
            {/* Sidebar Panel */}
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className="fixed top-0 right-0 z-50 h-full w-80 max-w-[85vw] bg-white shadow-2xl flex flex-col"
              dir="rtl"
            >
              {/* Sidebar Header */}
              <div className="flex items-center justify-between p-4 border-b border-gray-100">
                <h3 className="text-lg font-bold text-gray-900">الأقسام</h3>
                <button
                  onClick={() => setSidebarOpen(false)}
                  className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center hover:bg-gray-200 transition-colors"
                >
                  <X className="w-4 h-4 text-gray-600" />
                </button>
              </div>

              {/* Sidebar Nav */}
              <nav className="flex-1 overflow-y-auto p-3 space-y-1 custom-scrollbar">
                {sidebarSections.map((item) => {
                  const isActive = activeSection === item.id
                  return (
                    <button
                      key={item.id}
                      onClick={() => navigateToSection(item.id)}
                      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                        isActive
                          ? 'bg-[#E0F6FF] text-[#0A90D4] shadow-sm'
                          : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                      }`}
                    >
                      <item.icon className={`w-5 h-5 ${isActive ? 'text-[#1CB0F6]' : 'text-gray-400'}`} />
                      <span>{item.label}</span>
                    </button>
                  )
                })}
              </nav>

              {/* Sidebar Footer - Progress */}
              <div className="p-4 border-t border-gray-100 bg-gradient-to-t from-[#F0FAFF] to-white">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700">التقدم العام</span>
                  <span className="text-sm font-bold text-red-600">{stats.progress}%</span>
                </div>
                <Progress value={stats.progress} className="h-2" />
                <p className="text-xs text-gray-500 mt-2 text-center">
                  {stats.learned} من {stats.total} كلمة محفوظة
                </p>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* ─── Mobile Bottom Bar ───────────────────────────────── */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-sm border-t border-gray-200 flex justify-around py-2 px-1 safe-area-bottom">
        {[
          { section: null, label: 'الرئيسية', icon: LayoutDashboard },
          { section: 'lessons' as Section, label: 'الدروس', icon: BookOpenText },
          { section: 'practice' as Section, label: 'التمارين', icon: Target },
          { section: 'games' as Section, label: 'الألعاب', icon: Gamepad2 },
        ].map((item) => (
          <button
            key={item.label}
            onClick={() => item.section ? navigateToSection(item.section) : goBack()}
            className={`flex flex-col items-center gap-0.5 px-3 py-1 rounded-lg min-w-[56px] transition-colors ${
              (item.section === null && !activeSection) || activeSection === item.section
                ? 'text-red-600'
                : 'text-gray-400'
            }`}
          >
            <item.icon className="w-5 h-5" />
            <span className="text-[10px] font-medium">{item.label}</span>
          </button>
        ))}
        <button
          onClick={() => setSidebarOpen(true)}
          className="flex flex-col items-center gap-0.5 px-3 py-1 rounded-lg min-w-[56px] text-gray-400"
        >
          <Menu className="w-5 h-5" />
          <span className="text-[10px] font-medium">المزيد</span>
        </button>
      </nav>

      {/* ─── Auth Dialog ─────────────────────────────────────── */}
      <AuthDialog open={authOpen} onOpenChange={(open) => {
        if (!open && !isAuthenticated) return // prevent closing without login
        setAuthOpen(open)
      }} onLoginSuccess={() => {}} />

      {/* ─── Footer (desktop only) ──────────────────────────── */}
      {!activeSection && (
        <footer className="hidden lg:block border-t border-gray-200 bg-gray-50 mt-auto">
          <div className="max-w-6xl mx-auto px-6 py-4 text-center text-sm text-gray-500">
            مُضَّن — منصة تعلم اللغة الصينية HSK 1 • {stats.learned} من {stats.total} كلمة تم حفظها
          </div>
        </footer>
      )}
    </div>
  )
}
