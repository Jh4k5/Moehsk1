'use client'

import React, { useState, useMemo, useCallback, useEffect } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  BookOpen, CheckCircle, Volume2,
  MessageCircle, PenTool, GraduationCap,
  ArrowRight, ArrowLeft, Trophy, RotateCcw, Star,
  Lock, Flame, Zap, ChevronRight, Sparkles, Target
} from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { hsk1Lessons, hsk1AllWords, HSK1Word, HSK1Lesson } from '@/data/hsk1NewCurriculum'

// ─── TTS Helper ─────────────────────────────────────────────
const speak = (text: string, lang = 'zh-CN') => {
  if (typeof window !== 'undefined' && window.speechSynthesis) {
    window.speechSynthesis.cancel()
    const u = new SpeechSynthesisUtterance(text)
    u.lang = lang
    u.rate = 0.7
    window.speechSynthesis.speak(u)
  }
}

// ─── Types ──────────────────────────────────────────────────
interface ConversationTurn {
  speaker: 'A' | 'B'
  name: string
  hanzi: string
  pinyin: string
  arabic: string
}

interface GrammarRule {
  title: string
  description: string
  pattern: string
  example: string
  exampleAr: string
}

interface ExerciseQ {
  zh: string
  options: string[]
  correct: number
}

interface LessonContent {
  conversations: ConversationTurn[][]
  grammar: GrammarRule[]
  exercises: ExerciseQ[]
}

interface LessonProgress {
  completed: boolean
  stars: number
  xpEarned: number
  vocabReviewed: Set<string>
  exercisesCorrect: number
  exercisesTotal: number
}

// ─── Lesson Content (conversations, grammar, exercises) ─────
const lessonContent: Record<number, LessonContent> = {
  1: {
    conversations: [
      [
        { speaker: 'A', name: 'لي مينغ', hanzi: '老师好！', pinyin: 'Lǎoshī hǎo!', arabic: 'مرحباً أستاذ!' },
        { speaker: 'B', name: 'الأستاذة', hanzi: '你好！请问你叫什么名字？', pinyin: 'Nǐ hǎo! Qǐngwèn nǐ jiào shénme míngzi?', arabic: 'مرحباً! ما اسمك من فضلك؟' },
        { speaker: 'A', name: 'لي مينغ', hanzi: '我叫李明。老师，您好！', pinyin: 'Wǒ jiào Lǐ Míng. Lǎoshī, nín hǎo!', arabic: 'اسمي لي مينغ. أستاذ، مرحباً!' },
        { speaker: 'B', name: 'الأستاذة', hanzi: '李明，你也是中国人吗？', pinyin: 'Lǐ Míng, nǐ yě shì Zhōngguó rén ma?', arabic: 'لي مينغ، هل أنت أيضاً صيني؟' },
        { speaker: 'A', name: 'لي مينغ', hanzi: '我是中国人。很高兴认识您。', pinyin: 'Wǒ shì Zhōngguó rén. Hěn gāoxìng rènshi nín.', arabic: 'أنا صيني. سعيد بمعرفتكم.' },
        { speaker: 'B', name: 'الأستاذة', hanzi: '我也是。同学们好！', pinyin: 'Wǒ yě shì. Tóngxuémen hǎo!', arabic: 'أنا أيضاً. مرحباً أيها الطلاب!' },
      ],
      [
        { speaker: 'A', name: 'وانغ فانغ', hanzi: '你好！我叫王芳。你是哪国人？', pinyin: 'Nǐ hǎo! Wǒ jiào Wáng Fāng. Nǐ shì nǎ guó rén?', arabic: 'مرحباً! اسمي وانغ فانغ. من أي بلد أنت؟' },
        { speaker: 'B', name: 'سارة', hanzi: '你好！我叫萨拉。我是埃及人。', pinyin: 'Nǐ hǎo! Wǒ jiào Sàlā. Wǒ shì Āijí rén.', arabic: 'مرحباً! اسمي سارة. أنا مصرية.' },
        { speaker: 'A', name: 'وانغ فانغ', hanzi: '太好了！你也学习中文吗？', pinyin: 'Tài hǎo le! Nǐ yě xuéxí Zhōngwén ma?', arabic: 'رائع! هل أنت أيضاً تدرسين الصينية؟' },
        { speaker: 'B', name: 'سارة', hanzi: '对，我学习中文。中文很好。', pinyin: 'Duì, wǒ xuéxí Zhōngwén. Zhōngwén hěn hǎo.', arabic: 'نعم، أدرس الصينية. الصينية جيدة.' },
        { speaker: 'A', name: 'وانغ فانغ', hanzi: '谢谢！再见！', pinyin: 'Xièxie! Zàijiàn!', arabic: 'شكراً! مع السلامة!' },
        { speaker: 'B', name: 'سارة', hanzi: '再见！', pinyin: 'Zàijiàn!', arabic: 'مع السلامة!' },
      ],
    ],
    grammar: [
      { title: 'أسلوب التحية', description: '你好 هي أشهر تحية صينية. يمكن إضافة اسم الشخص أو لقبه بعدها.', pattern: '你好！(Nǐ hǎo!)', example: '你好，王老师！', exampleAr: 'مرحباً يا أستاذ وانغ!' },
      { title: 'صيغة "我叫"', description: 'للتعريف بالنفس نستخدم 我叫 + الاسم. كلمة 叫 تعني "يُسمّى".', pattern: '我叫 + [الاسم]', example: '我叫李明。', exampleAr: 'اسمي لي مينغ.' },
      { title: 'جملة "是"', description: 'هي فعل "يكون" في الصينية. تأتي بين الفاعل والمفعول.', pattern: 'فاعل + 是 + اسم/صفة', example: '我是学生。', exampleAr: 'أنا طالب.' },
      { title: 'أدوات الاستفهام', description: '吗 في نهاية الجملة تحولها إلى سؤال نعم/لا.', pattern: 'جملة عادية + 吗？', example: '你是中国人吗？', exampleAr: 'هل أنت صيني؟' },
    ],
    exercises: [
      { zh: 'ما معنى 你好؟', options: ['مع السلامة', 'مرحباً', 'شكراً', 'آسف'], correct: 1 },
      { zh: '我叫李明. تعني:', options: ['هو لي مينغ', 'اسمي لي مينغ', 'اسمه لي مينغ', 'أسميك لي مينغ'], correct: 1 },
      { zh: 'كيف تسأل "هل أنت صيني؟" بالصينية؟', options: ['你是中国人', '你是中国人吗？', '你是哪国人', '你好吗'], correct: 1 },
      { zh: '什么 معنى 再见؟', options: ['مرحباً', 'شكراً', 'مع السلامة', 'من فضلك'], correct: 2 },
      { zh: '老师 تعني:', options: ['طالب', 'طبيب', 'أستاذ/معلم', 'صديق'], correct: 2 },
      { zh: '怎么 تقول "أنا أيضاً"؟', options: ['我不是', '你是', '我也', '他们'], correct: 2 },
    ],
  },
  2: {
    conversations: [
      [
        { speaker: 'A', name: 'لي مينغ', hanzi: '你好，我是李明。请问你是哪国人？', pinyin: 'Nǐ hǎo, wǒ shì Lǐ Míng. Qǐngwèn nǐ shì nǎ guó rén?', arabic: 'مرحباً، أنا لي مينغ. من فضلك من أي بلد أنت؟' },
        { speaker: 'B', name: 'أحمد', hanzi: '我是埃及人。你也是中国人吗？', pinyin: 'Wǒ shì Āijí rén. Nǐ yě shì Zhōngguó rén ma?', arabic: 'أنا مصري. هل أنت أيضاً صيني؟' },
        { speaker: 'A', name: 'لي مينغ', hanzi: '对，我是中国人。认识你很高兴。', pinyin: 'Duì, wǒ shì Zhōngguó rén. Rènshi nǐ hěn gāoxìng.', arabic: 'نعم، أنا صيني. سعيد بمعرفتك.' },
        { speaker: 'B', name: 'أحمد', hanzi: '我也是。你叫什么名字？', pinyin: 'Wǒ yě shì. Nǐ jiào shénme míngzi?', arabic: 'أنا أيضاً. ما اسمك؟' },
        { speaker: 'A', name: 'لي مينغ', hanzi: '我叫李明。你呢？', pinyin: 'Wǒ jiào Lǐ Míng. Nǐ ne?', arabic: 'اسمي لي مينغ. وأنت؟' },
        { speaker: 'B', name: 'أحمد', hanzi: '我叫大卫。我是法国人。', pinyin: 'Wǒ jiào Dàwèi. Wǒ shì Fǎguó rén.', arabic: 'اسمي ديفيد. أنا فرنسي.' },
      ],
    ],
    grammar: [
      { title: 'الترتيب الأساسي SVO', description: 'الترتيب الأساسي في الصينية: فاعل + فعل + مفعول. خلاف اللغة العربية.', pattern: 'S (فاعل) + V (فعل) + O (مفعول)', example: '我学习中文。', exampleAr: 'أنا أدرس الصينية.' },
      { title: 'جملة 是', description: 'جملة "يكون" تصف الهوية أو الانتماء. تأتي بين الفاعل والاسم.', pattern: 'فاعل + 是 + اسم', example: '我是中国人。', exampleAr: 'أنا صيني.' },
      { title: 'الجنسيات', description: 'اسم البلد + 人 = شخص من ذلك البلد.', pattern: '[اسم البلد] + 人', example: '埃及人 / 法国人 / 泰国人', exampleAr: 'مصري / فرنسي / تايلاندي' },
    ],
    exercises: [
      { zh: 'الترتيب الأساسي في الصينية:', options: ['فعل + فاعل + مفعول', 'فاعل + فعل + مفعول', 'فاعل + مفعول + فعل', 'مفعول + فاعل + فعل'], correct: 1 },
      { zh: '我是中国人. تعني:', options: ['أنا من الصين', 'أنا صيني', 'أحب الصين', 'أعرف الصين'], correct: 1 },
      { zh: '法国人 تعني:', options: ['صيني', 'مصري', 'فرنسي', 'تايلاندي'], correct: 2 },
      { zh: '多少 تستخدم لسؤال عن:', options: ['المكان', 'الزمان', 'الكمية والسعر', 'الشخص'], correct: 2 },
      { zh: '你们 تعني:', options: ['أنا', 'أنت', 'هو', 'أنتم'], correct: 3 },
    ],
  },
  3: {
    conversations: [
      [
        { speaker: 'A', name: 'لي مينغ', hanzi: '你有几个孩子？', pinyin: 'Nǐ yǒu jǐ gè háizi?', arabic: 'كم عدد أطفالك؟' },
        { speaker: 'B', name: 'وانغ فانغ', hanzi: '我有两个孩子。一个是男孩，一个是女孩。', pinyin: 'Wǒ yǒu liǎng gè háizi. Yí ge shì nánhái, yí ge shì nǚhái.', arabic: 'لدي طفلان. واحد ذكر وواحد أنثى.' },
        { speaker: 'A', name: 'لي مينغ', hanzi: '你姐姐有几个孩子？', pinyin: 'Nǐ jiějie yǒu jǐ gè háizi?', arabic: 'كم عدد أطفال أختك الكبرى؟' },
        { speaker: 'B', name: 'وانغ فانغ', hanzi: '我姐姐有一个孩子。她很忙。', pinyin: 'Wǒ jiějie yǒu yí gè háizi. Tā hěn máng.', arabic: 'لأختي طفل واحد. هي مشغولة جداً.' },
        { speaker: 'A', name: 'لي مينغ', hanzi: '我也是学生，不是老师。', pinyin: 'Wǒ yě shì xuéshēng, bú shì lǎoshī.', arabic: 'أنا أيضاً طالب، لست معلماً.' },
        { speaker: 'B', name: 'وانغ فانغ', hanzi: '这是我的女朋友。她是中国人。', pinyin: 'Zhè shì wǒ de nǚpéngyou. Tā shì Zhōngguó rén.', arabic: 'هذه صديقتي. هي صينية.' },
      ],
    ],
    grammar: [
      { title: 'جملة 是 (النفي)', description: 'لنفي جملة "是" نستخدم 不 قبل 是.', pattern: 'فاعل + 不 + 是 + ...', example: '我不是学生。', exampleAr: 'لست طالباً.' },
      { title: 'أداة "的" الملكية', description: 'تُضاف بين صاحب الشيء والشيء المملوك.', pattern: 'فاعل + 的 + اسم', example: '这是我的书。', exampleAr: 'هذا كتابي.' },
      { title: 'جملة 有', description: 'للتعبير عن الملكية نستخدم 有 بعد الفاعل.', pattern: 'فاعل + 有 + عدد + اسم', example: '我有两个弟弟。', exampleAr: 'لدي أخوان أصغران.' },
    ],
    exercises: [
      { zh: '这不是我的书. تعني:', options: ['هذا كتابي', 'هذا ليس كتابي', 'أين كتابي', 'هل هذا كتابي'], correct: 1 },
      { zh: '我有两个孩子. تعني:', options: ['أريد طفلين', 'عندي طفلان', 'أعرف طفلين', 'أرى طفلين'], correct: 1 },
      { zh: '你姐姐 تعني:', options: ['أخوك الأصغر', 'أخوك الأكبر', 'أختك الكبرى', 'أمك'], correct: 2 },
      { zh: '女朋友 تعني:', options: ['صديق (ذكر)', 'حبيبة', 'زميلة', 'أخت'], correct: 1 },
      { zh: '我们 تعني:', options: ['أنا', 'أنت', 'هو', 'نحن'], correct: 3 },
    ],
  },
  4: {
    conversations: [
      [
        { speaker: 'A', name: 'لي مينغ', hanzi: '今天你休息吗？', pinyin: 'Jīntiān nǐ xiūxi ma?', arabic: 'هل تستريح اليوم؟' },
        { speaker: 'B', name: 'وانغ فانغ', hanzi: '对，今天我休息。你呢？', pinyin: 'Duì, jīntiān wǒ xiūxi. Nǐ ne?', arabic: 'نعم، أنا أستريح اليوم. وأنت؟' },
        { speaker: 'A', name: 'لي مينغ', hanzi: '我不休息，我要去学校。', pinyin: 'Wǒ bù xiūxi, wǒ yào qù xuéxiào.', arabic: 'لا أستريح، أريد الذهاب للمدرسة.' },
        { speaker: 'B', name: 'وانغ فانغ', hanzi: '你有几个同学？', pinyin: 'Nǐ yǒu jǐ gè tóngxué?', arabic: 'كم عدد زملائك في الفصل؟' },
        { speaker: 'A', name: 'لي مينغ', hanzi: '我们有二十个同学。', pinyin: 'Wǒmen yǒu èrshí gè tóngxué.', arabic: 'لدينا عشرون زميلاً.' },
        { speaker: 'B', name: 'وانغ فانغ', hanzi: '真多！你们一起学习吗？', pinyin: 'Zhēn duō! Nǐmen yīqǐ xuéxí ma?', arabic: 'كثيرون! هل تدرسون معاً؟' },
      ],
    ],
    grammar: [
      { title: 'جملة 有 (النفي)', description: 'لنفي "يوجد/لدي" نستخدم 没 before 有.', pattern: 'فاعل + 没(有) + ...', example: '我没有姐姐。', exampleAr: 'ليس لدي أخت كبرى.' },
      { title: 'الأرقام', description: 'الصينية تستخدم نظام عشري: 11=十一، 20=二十.', pattern: '10-19: 十+[رقم] / 20+: [عشرات]+[آحاد]', example: '二十三 (23)', exampleAr: 'ثلاثة وعشرون' },
      { title: 'أيام الأسبوع', description: 'يوم = 星期X (الاثنين=星期一 ... الجمعة=星期五)', pattern: '星期 + [رقم 1-6]', example: '星期一 = الاثنين', exampleAr: '星期三 = الأربعاء' },
    ],
    exercises: [
      { zh: '十五 تعني:', options: ['10', '12', '15', '50'], correct: 2 },
      { zh: '我没有姐姐 تعني:', options: ['عندي أخت كبرى', 'ليس لدي أخت كبرى', 'أريد أختاً', 'أعرف أختاً'], correct: 1 },
      { zh: '星期三 هو:', options: ['الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس'], correct: 2 },
      { zh: '休息 تعني:', options: ['يعمل', 'يستريح', 'يأكل', 'ينام'], correct: 1 },
      { zh: '今天我休息. تعني:', options: ['سأعمل اليوم', 'أنا أستريح اليوم', 'استرحت أمس', 'سأستريح غداً'], correct: 1 },
    ],
  },
  5: {
    conversations: [
      [
        { speaker: 'A', name: 'لي مينغ', hanzi: '请问，你的手机号是多少？', pinyin: 'Qǐngwèn, nǐ de shǒujī hào shì duōshao?', arabic: 'من فضلك، ما رقم هاتفك المحمول؟' },
        { speaker: 'B', name: 'وانغ فانغ', hanzi: '我的手机号是一三八零零一二三四五六。', pinyin: 'Wǒ de shǒujī hào shì yī sān bā líng líng yī èr sān sì wǔ liù.', arabic: 'رقم هاتفي 138-0012-3456.' },
        { speaker: 'A', name: 'لي مينغ', hanzi: '谢谢。现在几点了？', pinyin: 'Xièxie. Xiànzài jǐ diǎn le?', arabic: 'شكراً. كم الساعة الآن؟' },
        { speaker: 'B', name: 'وانغ فانغ', hanzi: '现在三点十五分。', pinyin: 'Xiànzài sān diǎn shíwǔ fēn.', arabic: 'الآن الثالثة والربع.' },
        { speaker: 'A', name: 'لي مينغ', hanzi: '好，我走了。再见！', pinyin: 'Hǎo, wǒ zǒu le. Zàijiàn!', arabic: 'حسناً، سأذهب. مع السلامة!' },
        { speaker: 'B', name: 'وانغ فانغ', hanzi: '再见！', pinyin: 'Zàijiàn!', arabic: 'مع السلامة!' },
      ],
    ],
    grammar: [
      { title: 'الوقت (الساعات)', description: 'الساعة في الصينية: رقم + 点 (diǎn)', pattern: 'الآن + [رقم] + 点', example: '现在是三点。', exampleAr: 'الآن الساعة الثالثة.' },
      { title: 'كم يسأل عن رقم', description: '多少 يسأل عن رقم الهاتف أو السعر.', pattern: '手机号 + 是 + 多少؟', example: '你的手机号是多少？', exampleAr: 'ما رقم هاتفك؟' },
      { title: 'الجملة الاسمية', description: 'في الصينية يمكن أن يكون الاسم جملة خبرية بدون فعل.', pattern: 'اسم + (时间词)', example: '今天星期五。', exampleAr: 'اليوم الجمعة.' },
    ],
    exercises: [
      { zh: '八点半 تعني:', options: ['8:00', '8:15', '8:30', '8:45'], correct: 2 },
      { zh: '手机号是多少 سؤال عن:', options: ['الاسم', 'رقم الهاتف', 'العنوان', 'العمر'], correct: 1 },
      { zh: '今天星期三 تعني:', options: ['اليوم الاثنين', 'اليوم الثلاثاء', 'اليوم الأربعاء', 'اليوم الخميس'], correct: 2 },
      { zh: '早上七点 تعني:', options: ['7 مساءً', '7 صباحاً', '7 ليلاً', '7 بعد الظهر'], correct: 1 },
      { zh: '明天 تعني:', options: ['اليوم', 'أمس', 'غداً', 'الآن'], correct: 2 },
    ],
  },
  6: {
    conversations: [
      [
        { speaker: 'A', name: 'لي مينغ', hanzi: '你怎么去学校？', pinyin: 'Nǐ zěnme qù xuéxiào?', arabic: 'كيف تذهب للمدرسة؟' },
        { speaker: 'B', name: 'وانغ فانغ', hanzi: '我坐公共汽车去学校。', pinyin: 'Wǒ zuò gōnggòng qìchē qù xuéxiào.', arabic: 'أذهب بالحافلة.' },
        { speaker: 'A', name: 'لي مينغ', hanzi: '你几点下班？', pinyin: 'Nǐ jǐ diǎn xiàbān?', arabic: 'كم تنهي العمل؟' },
        { speaker: 'B', name: 'وانغ فانغ', hanzi: '我晚上六点半下班。', pinyin: 'Wǒ wǎnshang liù diǎn bàn xiàbān.', arabic: 'أنهي العمل الساعة 6:30 مساءً.' },
        { speaker: 'A', name: 'لي مينغ', hanzi: '我早上八点上班。', pinyin: 'Wǒ zǎoshang bā diǎn shàngbān.', arabic: 'أبدأ العمل الساعة 8 صباحاً.' },
        { speaker: 'B', name: 'وانغ فانغ', hanzi: '你很忙吧？', pinyin: 'Nǐ hěn máng ba?', arabic: 'أنت مشغول أليس كذلك؟' },
      ],
    ],
    grammar: [
      { title: '怎么 (كيف)', description: '怎么 يسأل عن الطريقة أو الكيفية.', pattern: '怎么 + فعل', example: '你怎么去学校？', exampleAr: 'كيف تذهب للمدرسة؟' },
      { title: 'نصف الساعة 半', description: '半 تأتي بعد رقم الساعة للدلالة على النصف.', pattern: '[رقم] + 点 + 半', example: '六点半', exampleAr: '6:30 (ستة ونصف)' },
    ],
    exercises: [
      { zh: '怎么 تعني:', options: ['ماذا', 'أين', 'كيف', 'متى'], correct: 2 },
      { zh: '六点半 تعني:', options: ['6:00', '6:15', '6:30', '6:45'], correct: 2 },
      { zh: '下班 تعني:', options: ['يذهب للعمل', 'ينهي العمل', 'يستريح', 'ينام'], correct: 1 },
      { zh: '上班 تعني:', options: ['ينهي العمل', 'يذهب للعمل', 'يعود للبيت', 'يخرج'], correct: 1 },
      { zh: '已经 تعني:', options: ['لا يزال', 'بالفعل', 'سابقاً', 'للكل'], correct: 1 },
    ],
  },
  7: {
    conversations: [
      [
        { speaker: 'A', name: 'لي مينغ', hanzi: '你爸爸在哪儿工作？', pinyin: 'Nǐ bàba zài nǎr gōngzuò?', arabic: 'أين يعمل أبوك؟' },
        { speaker: 'B', name: 'وانغ فانغ', hanzi: '我爸爸在医院工作。他是医生。', pinyin: 'Wǒ bàba zài yīyuàn gōngzuò. Tā shì yīshēng.', arabic: 'أبي يعمل في المستشفى. هو طبيب.' },
        { speaker: 'A', name: 'لي مينغ', hanzi: '我妈妈也在医院工作。她是护士。', pinyin: 'Wǒ māma yě zài yīyuàn gōngzuò. Tā shì hùshi.', arabic: 'أمي أيضاً تعمل في المستشفى. هي ممرضة.' },
        { speaker: 'B', name: 'وانغ فانغ', hanzi: '你爸爸你妈妈都在医院工作！', pinyin: 'Nǐ bàba nǐ māma dōu zài yīyuàn gōngzuò!', arabic: 'أبوك وأمك يعملان في المستشفى!' },
        { speaker: 'A', name: 'لي مينغ', hanzi: '对。这个医院很大。', pinyin: 'Duì. Zhège yīyuàn hěn dà.', arabic: 'نعم. هذا المستشفى كبير جداً.' },
        { speaker: 'B', name: 'وانغ فانغ', hanzi: '这是新医院还是旧医院？', pinyin: 'Zhè shì xīn yīyuàn háishì jiù yīyuàn?', arabic: 'هل هذا مستشفى جديد أم قديم؟' },
      ],
    ],
    grammar: [
      { title: '也 و 都', description: '也 تأتي قبل الفعل (أيضاً). 都 تأتي بعد الفاعل (جميعاً/كل).', pattern: 'فاعل + 也/都 + فعل', example: '我也学习中文。我们都去。', exampleAr: 'أنا أيضاً أدرس الصينية. نحن جميعاً نذهب.' },
      { title: 'موقع الوقت في الجملة', description: 'كلمات الوقت تأتي قبل الفعل أو في بداية الجملة.', pattern: 'فاعل + [وقت] + [مكان] + فعل', example: '我明天在学校学习。', exampleAr: 'سأدرس في المدرسة غداً.' },
      { title: 'أداة 了', description: '了 في نهاية الجملة تعبر عن تغيير الحالة أو اكتمال الفعل.', pattern: 'جملة + 了', example: '下雨了。', exampleAr: 'نزل المطر (بدأ ينزل).' },
    ],
    exercises: [
      { zh: '也 تعني:', options: ['كل', 'لا', 'أيضاً', 'لكن'], correct: 2 },
      { zh: '都 تعني:', options: ['أيضاً', 'كل/جميع', 'لا', 'بعض'], correct: 1 },
      { zh: '下了雨 تعبر عن:', options: ['لا تمطر', 'ستمطر', 'نزل المطر (تغيير)', 'تمطر دائماً'], correct: 2 },
      { zh: '这是新的. 新 تعني:', options: ['قديم', 'جميل', 'جديد', 'كبير'], correct: 2 },
      { zh: '医院 تعني:', options: ['مدرسة', 'مستشفى', 'بنك', 'شركة'], correct: 1 },
    ],
  },
  8: {
    conversations: [
      [
        { speaker: 'A', name: 'لي مينغ', hanzi: '请问，图书馆在哪儿？', pinyin: 'Qǐngwèn, túshūguǎn zài nǎr?', arabic: 'من فضلك، أين المكتبة؟' },
        { speaker: 'B', name: 'وانغ فانغ', hanzi: '图书馆在学校的前面。', pinyin: 'Túshūguǎn zài xuéxiào de qiánmiàn.', arabic: 'المكتبة أمام المدرسة.' },
        { speaker: 'A', name: 'لي مينغ', hanzi: '银行在左边还是右边？', pinyin: 'Yínháng zài zuǒbiān háishì yòubiān?', arabic: 'هل البنك على اليسار أم اليمين؟' },
        { speaker: 'B', name: 'وانغ فانغ', hanzi: '银行在右边，商店在左边。', pinyin: 'Yínháng zài yòubiān, shāngdiàn zài zuǒbiān.', arabic: 'البنك على اليمين، المتجر على اليسار.' },
        { speaker: 'A', name: 'لي مينغ', hanzi: '你能帮我吗？', pinyin: 'Nǐ néng bāng wǒ ma?', arabic: 'هل تستطيع مساعدتي؟' },
        { speaker: 'B', name: 'وانغ فانغ', hanzi: '当然可以！', pinyin: 'Dāngrán kěyǐ!', arabic: 'بالطبع!' },
      ],
    ],
    grammar: [
      { title: 'حرف الجر 在', description: 'في تُستخدم للتعبير عن الموقع أو المكان.', pattern: '在 + مكان', example: '我在教室。', exampleAr: 'أنا في الفصل.' },
      { title: 'كلمات المكان', description: '前面(أمام)،后面(خلف)،左边(يسار)،右边(يمين)،旁边(بجانب)،对面(مقابل)', pattern: 'الشيء + 在 + [مكان] + 方位', example: '银行在学校旁边。', exampleAr: 'البنك بجانب المدرسة.' },
      { title: 'فعل "能" (يستطيع)', description: '能 يعبر عن القدرة العامة أو الإذن.', pattern: 'فاعل + 能 + فعل', example: '你能来吗？', exampleAr: 'هل تستطيع المجيء؟' },
    ],
    exercises: [
      { zh: '前面 تعني:', options: ['خلف', 'فوق', 'أمام', 'تحت'], correct: 2 },
      { zh: '在 + مكان يعبر عن:', options: ['الزمان', 'الموقع', 'السبب', 'الطريقة'], correct: 1 },
      { zh: '对面 تعني:', options: ['بجانب', 'مقابل', 'بعيد', 'قريب'], correct: 1 },
      { zh: '能 تعني:', options: ['يريد', 'يستطيع', 'يجب', 'يبدأ'], correct: 1 },
      { zh: '银行在左边. 左边 تعني:', options: ['فوق', 'تحت', 'يسار', 'يمين'], correct: 2 },
    ],
  },
  9: {
    conversations: [
      [
        { speaker: 'A', name: 'لي مينغ', hanzi: '你明天做什么？', pinyin: 'Nǐ míngtiān zuò shénme?', arabic: 'ماذا ستفعل غداً؟' },
        { speaker: 'B', name: 'وانغ فانغ', hanzi: '我明天上午在学校学习。', pinyin: 'Wǒ míngtiān shàngwǔ zài xuéxiào xuéxí.', arabic: 'سأدرس في المدرسة غداً صباحاً.' },
        { speaker: 'A', name: 'لي مينغ', hanzi: '你能来吗？我们一起学习。', pinyin: 'Nǐ néng lái ma? Wǒmen yīqǐ xuéxí.', arabic: 'هل تستطيع المجيء؟ لندرس معاً.' },
        { speaker: 'B', name: 'وانغ فانغ', hanzi: '可以。我们一起学习吧！', pinyin: 'Kěyǐ. Wǒmen yīqǐ xuéxí ba!', arabic: 'نعم. لندرس معاً!' },
        { speaker: 'A', name: 'لي مينغ', hanzi: '学校里有很多学生。', pinyin: 'Xuéxiào lǐ yǒu hěn duō xuéshēng.', arabic: 'في المدرسة كثير من الطلاب.' },
        { speaker: 'B', name: 'وانغ فانغ', hanzi: '对，我们学校有三百个学生。', pinyin: 'Duì, wǒmen xuéxiào yǒu sānbǎi gè xuéshēng.', arabic: 'نعم، في مدرستنا ثلاثمائة طالب.' },
      ],
    ],
    grammar: [
      { title: 'جمل الوجود (在...有)', description: 'يعبر عن وجود شيء في مكان: المكان + 在 + يوجد.', pattern: 'مكان + 有 + شيء/شخص', example: '学校里有一个图书馆。', exampleAr: 'في المدرسة مكتبة.' },
      { title: 'علامات الفعل', description: '正在 = يفعل الآن، 了 = انتهى، 过 = مرّ بتجربة.', pattern: '正在/了/过 + فعل', example: '他正在学习。我吃了。', exampleAr: 'هو يدرس الآن. أنا أكلت.' },
      { title: 'التعبير عن المستقبل', description: '明天/后天 + فعل للتعبير عن المستقبل.', pattern: '我 + [وقت مستقبلي] + [مكان] + فعل', example: '我明天在学校学习。', exampleAr: 'سأدرس في المدرسة غداً.' },
    ],
    exercises: [
      { zh: '桌子上有一本书. تعني:', options: ['الكتاب على الطاولة', 'على الطاولة كتاب', 'أريد كتاباً', 'الكتاب بعيد'], correct: 1 },
      { zh: '正在 تعني:', options: ['كان', 'سيكون', 'يفعل الآن', 'عادةً'], correct: 2 },
      { zh: '上午 تعني:', options: ['بعد الظهر', 'مساءً', 'صباحاً (قبل الظهر)', 'ليلاً'], correct: 2 },
      { zh: '桌子前面有谁؟ سؤال عن:', options: ['الزمان', 'الشخص الموجود', 'السبب', 'الطريقة'], correct: 1 },
      { zh: '一起 تعني:', options: ['وحيد', 'معاً', 'سريع', 'كثير'], correct: 1 },
    ],
  },
  10: {
    conversations: [
      [
        { speaker: 'A', name: 'لي مينغ', hanzi: '这儿的苹果真便宜！', pinyin: 'Zhèr de píngguǒ zhēn piányí!', arabic: 'التفاح هنا رخيص فعلاً!' },
        { speaker: 'B', name: 'البائعة', hanzi: '是啊，三块钱一斤。你要多少？', pinyin: 'Shì a, sān kuài qián yì jīn. Nǐ yào duōshao?', arabic: 'نعم، ثلاثة يوانات للرطل. كم تريد؟' },
        { speaker: 'A', name: 'لي مينغ', hanzi: '我要两斤苹果和一斤香蕉。', pinyin: 'Wǒ yào liǎng jīn píngguǒ hé yì jīn xiāngjiāo.', arabic: 'أريد رطلين تفاح ورطلاً موز.' },
        { speaker: 'B', name: 'البائعة', hanzi: '好的。一共十二块。', pinyin: 'Hǎo de. Yīgòng shíèr kuài.', arabic: 'حسناً. المجموع اثنا عشر يواناً.' },
        { speaker: 'A', name: 'لي مينغ', hanzi: '这个很大，那个很小。', pinyin: 'Zhège hěn dà, nàge hěn xiǎo.', arabic: 'هذا كبير جداً، ذلك صغير جداً.' },
        { speaker: 'B', name: 'البائعة', hanzi: '你买大的还是小的？', pinyin: 'Nǐ mǎi dà de háishì xiǎo de?', arabic: 'تشتري الكبير أم الصغير؟' },
      ],
      [
        { speaker: 'A', name: 'لي مينغ', hanzi: '这件衣服多少钱？', pinyin: 'Zhè jiàn yīfu duōshao qián?', arabic: 'بكم هذه الملابس؟' },
        { speaker: 'B', name: 'البائعة', hanzi: '一百五十块。', pinyin: 'Yìbǎi wǔshí kuài.', arabic: 'مئة وخمسون يواناً.' },
        { speaker: 'A', name: 'لي مينغ', hanzi: '太贵了！有没有便宜一点的？', pinyin: 'Tài guì le! Yǒu méiyǒu piányí yìdiǎn de?', arabic: 'غالٍ جداً! هل هناك شيء أرخص؟' },
        { speaker: 'B', name: 'البائعة', hanzi: '这件五十块，合适吗？', pinyin: 'Zhè jiàn wǔshí kuài, héshì ma?', arabic: 'هذه بخمسين يواناً، هل تناسب؟' },
      ],
    ],
    grammar: [
      { title: 'التعبير عن المال', description: '块 (yuán) وحدة النقد. 一百五十块 = 150 يوان.', pattern: '[رقم] + 块(钱)', example: '一共二十块。', exampleAr: 'المجموع عشرون يواناً.' },
      { title: 'جملة الصفة', description: 'الصفة يمكن أن تكون خبراً مباشرة بدون 是. نستخدم 很 كحرف ربط.', pattern: 'فاعل + 很 + صفة', example: '这个很大。', exampleAr: 'هذا كبير جداً.' },
      { title: '真 (حقاً)', description: '真 تُستخدم للتأكيد على الصفة مثل "فعلاً".', pattern: '真 + صفة + (了)', example: '真好！/真便宜！', exampleAr: 'رائع فعلاً! / رخيص فعلاً!' },
    ],
    exercises: [
      { zh: '便宜 تعني:', options: ['غالٍ', 'كبير', 'رخيص', 'جديد'], correct: 2 },
      { zh: '一百五十块 تعني:', options: ['15 يوان', '105 يوان', '150 يوان', '1050 يوان'], correct: 2 },
      { zh: '真贵了! تعني:', options: ['رخيص', 'معتدل', 'غالٍ فعلاً', 'مجاني'], correct: 2 },
      { zh: '太大了 تعني:', options: ['صغير جداً', 'كبير جداً', 'طويل', 'قصير'], correct: 1 },
      { zh: '合适 تعني:', options: ['غالي', 'مناسب', 'بعيد', 'قديم'], correct: 1 },
    ],
  },
}

// ─── Color System ───────────────────────────────────────────
const LESSON_COLORS = [
  { bg: '#1CB0F6', light: '#E8F7FF', dark: '#0A8FD6', gradient: 'from-[#1CB0F6] to-[#0EA5E9]' },
  { bg: '#10B981', light: '#ECFDF5', dark: '#059669', gradient: 'from-[#10B981] to-[#34D399]' },
  { bg: '#F59E0B', light: '#FFFBEB', dark: '#D97706', gradient: 'from-[#F59E0B] to-[#FBBF24]' },
  { bg: '#EF4444', light: '#FEF2F2', dark: '#DC2626', gradient: 'from-[#EF4444] to-[#F87171]' },
  { bg: '#8B5CF6', light: '#F5F3FF', dark: '#7C3AED', gradient: 'from-[#8B5CF6] to-[#A78BFA]' },
  { bg: '#EC4899', light: '#FDF2F8', dark: '#DB2777', gradient: 'from-[#EC4899] to-[#F472B6]' },
  { bg: '#14B8A6', light: '#F0FDFA', dark: '#0D9488', gradient: 'from-[#14B8A6] to-[#2DD4BF]' },
  { bg: '#F97316', light: '#FFF7ED', dark: '#EA580C', gradient: 'from-[#F97316] to-[#FB923C]' },
  { bg: '#6366F1', light: '#EEF2FF', dark: '#4F46E5', gradient: 'from-[#6366F1] to-[#818CF8]' },
  { bg: '#06B6D4', light: '#ECFEFF', dark: '#0891B2', gradient: 'from-[#06B6D4] to-[#22D3EE]' },
]

const XP_REWARDS = { vocabReview: 5, exerciseCorrect: 10, lessonComplete: 50 }

// ─── Animation Variants ─────────────────────────────────────
const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -20 },
}

const staggerContainer = {
  animate: { transition: { staggerChildren: 0.06 } },
}

const scaleIn = {
  initial: { opacity: 0, scale: 0.8 },
  animate: { opacity: 1, scale: 1 },
}

const starPop = {
  initial: { scale: 0, rotate: -180 },
  animate: { scale: 1, rotate: 0 },
  transition: { type: 'spring', stiffness: 300, damping: 15 },
}

// ─── Main Component ─────────────────────────────────────────
export default function LessonSystem() {
  const [selectedLesson, setSelectedLesson] = useState<number | null>(null)
  const [activeTab, setActiveTab] = useState('vocab')
  const [answers, setAnswers] = useState<Record<number, number>>({})
  const [showResults, setShowResults] = useState(false)
  const [flippedCards, setFlippedCards] = useState<Set<string>>(new Set())
  const [reviewedWords, setReviewedWords] = useState<Set<string>>(new Set())
  const [activeConv, setActiveConv] = useState(0)
  const [convRevealIndex, setConvRevealIndex] = useState(0)
  const [totalXP, setTotalXP] = useState(0)
  const [streak, setStreak] = useState(0)
  const [lessonStars, setLessonStars] = useState<Record<number, number>>({})
  const [completedLessons, setCompletedLessons] = useState<Set<number>>(new Set())
  const [matchPairs, setMatchPairs] = useState<{ zh: string; ar: string }[]>([])
  const [matchSelected, setMatchSelected] = useState<{ side: 'zh' | 'ar'; idx: number; text: string } | null>(null)
  const [matchMatched, setMatchMatched] = useState<Set<string>>(new Set())
  const [matchErrors, setMatchErrors] = useState<Set<string>>(new Set())
  const [exerciseMode, setExerciseMode] = useState<'quiz' | 'match'>('quiz')

  // Load saved progress
  useEffect(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('lessonSystemProgress')
        if (saved) {
          const data = JSON.parse(saved)
          if (data.completedLessons) setCompletedLessons(new Set(data.completedLessons))
          if (data.totalXP) setTotalXP(data.totalXP)
          if (data.streak) setStreak(data.streak)
          if (data.lessonStars) setLessonStars(data.lessonStars)
        }
        // Calculate streak from dates
        const today = new Date().toDateString()
        const lastDate = localStorage.getItem('lessonSystemLastDate')
        if (lastDate === today) {
          // Already recorded today
        } else if (lastDate) {
          const diff = Math.floor((new Date(today).getTime() - new Date(lastDate).getTime()) / 86400000)
          if (diff === 1) {
            // Keep streak
          } else if (diff > 1) {
            setStreak(0)
          }
        }
      } catch {}
    }
  }, [])

  // Save progress
  const saveProgress = useCallback(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('lessonSystemProgress', JSON.stringify({
        completedLessons: [...completedLessons],
        totalXP,
        streak,
        lessonStars,
      }))
      localStorage.setItem('lessonSystemLastDate', new Date().toDateString())
    }
  }, [completedLessons, totalXP, streak, lessonStars])

  useEffect(() => { saveProgress() }, [saveProgress])

  const addXP = useCallback((amount: number) => {
    setTotalXP(prev => prev + amount)
  }, [])

  const markLessonCompleted = useCallback((lessonNum: number, stars: number) => {
    setCompletedLessons(prev => {
      const next = new Set(prev)
      next.add(lessonNum)
      return next
    })
    setLessonStars(prev => ({
      ...prev,
      [lessonNum]: Math.max(prev[lessonNum] || 0, stars),
    }))
    setStreak(prev => prev + 1)
    addXP(XP_REWARDS.lessonComplete + (stars * 20))
  }, [addXP])

  const currentLesson = selectedLesson ? hsk1Lessons.find(l => l.num === selectedLesson) : null
  const currentContent = selectedLesson ? lessonContent[selectedLesson] : null
  const currentWords = currentLesson?.words || []
  const colorIndex = ((selectedLesson || 1) - 1) % LESSON_COLORS.length
  const colors = LESSON_COLORS[colorIndex]

  const overallProgress = Math.round((completedLessons.size / hsk1Lessons.length) * 100)
  const userLevel = Math.floor(totalXP / 100) + 1

  // Determine unlocked lessons
  const isUnlocked = useCallback((lessonNum: number) => {
    if (lessonNum === 1) return true
    return completedLessons.has(lessonNum - 1)
  }, [completedLessons])

  // Star calculation
  const calculateStars = useCallback((correct: number, total: number) => {
    const pct = total > 0 ? correct / total : 0
    if (pct >= 0.9) return 3
    if (pct >= 0.7) return 2
    if (pct >= 0.5) return 1
    return 0
  }, [])

  // Handle exercise check
  const handleCheckAnswers = useCallback(() => {
    if (!currentContent || !selectedLesson) return
    setShowResults(true)
    const total = currentContent.exercises.length
    let correct = 0
    currentContent.exercises.forEach((q, i) => {
      if (answers[i] === q.correct) correct++
    })
    if (correct >= Math.ceil(total * 0.6)) {
      const stars = calculateStars(correct, total)
      markLessonCompleted(selectedLesson, stars)
    }
  }, [currentContent, answers, selectedLesson, calculateStars, markLessonCompleted])

  // Handle match completion
  const handleMatchComplete = useCallback(() => {
    if (!selectedLesson || matchMatched.size < matchPairs.length) return
    const errors = matchErrors.size
    const stars = errors === 0 ? 3 : errors <= 2 ? 2 : 1
    markLessonCompleted(selectedLesson, stars)
  }, [selectedLesson, matchMatched, matchErrors, markLessonCompleted])

  useEffect(() => {
    if (matchPairs.length > 0 && matchMatched.size === matchPairs.length) {
      handleMatchComplete()
    }
  }, [matchMatched, matchPairs, handleMatchComplete])

  const handleResetExercises = useCallback(() => {
    setAnswers({})
    setShowResults(false)
  }, [])

  const handleResetMatch = useCallback(() => {
    setMatchSelected(null)
    setMatchMatched(new Set())
    setMatchErrors(new Set())
  }, [])

  const goBack = useCallback(() => {
    setSelectedLesson(null)
    setActiveTab('vocab')
    setAnswers({})
    setShowResults(false)
    setFlippedCards(new Set())
    setReviewedWords(new Set())
    setActiveConv(0)
    setConvRevealIndex(0)
    setMatchSelected(null)
    setMatchMatched(new Set())
    setMatchErrors(new Set())
    setExerciseMode('quiz')
  }, [])

  // Initialize match pairs when switching to match mode
  useEffect(() => {
    if (selectedLesson && exerciseMode === 'match' && currentWords.length > 0) {
      const shuffled = [...currentWords].sort(() => Math.random() - 0.5).slice(0, Math.min(6, currentWords.length))
      setMatchPairs(shuffled.map(w => ({ zh: w.chinese, ar: w.arabic })))
      setMatchSelected(null)
      setMatchMatched(new Set())
      setMatchErrors(new Set())
    }
  }, [selectedLesson, exerciseMode, currentWords])

  // Reveal conversation turns one by one
  useEffect(() => {
    if (selectedLesson && activeTab === 'conv') {
      setConvRevealIndex(0)
    }
  }, [selectedLesson, activeTab])

  // Flip card handler
  const toggleFlip = useCallback((wordKey: string) => {
    setFlippedCards(prev => {
      const next = new Set(prev)
      if (next.has(wordKey)) {
        next.delete(wordKey)
      } else {
        next.add(wordKey)
        // XP for reviewing a new word
        if (!reviewedWords.has(wordKey)) {
          setReviewedWords(prev2 => {
            const next2 = new Set(prev2)
            next2.add(wordKey)
            return next2
          })
          addXP(XP_REWARDS.vocabReview)
        }
      }
      return next
    })
  }, [reviewedWords, addXP])

  // Match selection handler
  const handleMatchSelect = useCallback((side: 'zh' | 'ar', idx: number, text: string) => {
    if (matchMatched.has(text)) return

    if (!matchSelected) {
      setMatchSelected({ side, idx, text })
      return
    }

    if (matchSelected.side === side) {
      setMatchSelected({ side, idx, text })
      return
    }

    // Check if match is correct
    const zhWord = side === 'zh' ? text : matchSelected.text
    const arWord = side === 'ar' ? text : matchSelected.text
    const pair = matchPairs.find(p => p.zh === zhWord && p.ar === arWord)

    if (pair) {
      setMatchMatched(prev => {
        const next = new Set(prev)
        next.add(zhWord)
        next.add(arWord)
        return next
      })
      addXP(XP_REWARDS.exerciseCorrect)
    } else {
      setMatchErrors(prev => {
        const next = new Set(prev)
        next.add(zhWord)
        next.add(arWord)
        setTimeout(() => {
          setMatchErrors(p => {
            const n = new Set(p)
            n.delete(zhWord)
            n.delete(arWord)
            return n
          })
        }, 600)
        return next
      })
    }
    setMatchSelected(null)
  }, [matchSelected, matchMatched, matchPairs, addXP])

  // ─── RENDER: Lesson Selection Grid ─────────────────────────
  if (!selectedLesson) {
    return (
      <div className="w-full max-w-4xl mx-auto px-4 pb-8" dir="rtl">
        {/* Header with XP, Streak, Level */}
        <motion.div
          className="text-center mb-6"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h2 className="text-2xl font-bold mb-2" style={{ color: '#1CB0F6' }}>
            📚 الدروس — HSK 1
          </h2>
          <div className="flex items-center justify-center gap-4 flex-wrap">
            <Badge className="bg-amber-100 text-amber-700 border-amber-200 px-3 py-1 text-sm gap-1">
              <Flame className="w-4 h-4" /> {streak} يوم متتالي
            </Badge>
            <Badge className="bg-blue-100 text-blue-700 border-blue-200 px-3 py-1 text-sm gap-1">
              <Zap className="w-4 h-4" /> {totalXP} XP
            </Badge>
            <Badge className="bg-purple-100 text-purple-700 border-purple-200 px-3 py-1 text-sm gap-1">
              <Sparkles className="w-4 h-4" /> المستوى {userLevel}
            </Badge>
          </div>
        </motion.div>

        {/* Overall Progress Bar */}
        <motion.div className="mb-8" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.1 }}>
          <div className="flex items-center justify-between mb-2 text-sm">
            <span className="text-gray-500">التقدم العام</span>
            <span className="font-bold" style={{ color: '#1CB0F6' }}>{completedLessons.size}/{hsk1Lessons.length} دروس</span>
          </div>
          <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
            <motion.div
              className="h-full rounded-full bg-gradient-to-l from-[#1CB0F6] to-[#0EA5E9]"
              initial={{ width: 0 }}
              animate={{ width: `${overallProgress}%` }}
              transition={{ duration: 0.8, ease: 'easeOut' }}
            />
          </div>
        </motion.div>

        {/* Lesson Grid */}
        <motion.div
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"
          variants={staggerContainer}
          initial="initial"
          animate="animate"
        >
          {hsk1Lessons.map((lesson) => {
            const unlocked = isUnlocked(lesson.num)
            const completed = completedLessons.has(lesson.num)
            const stars = lessonStars[lesson.num] || 0
            const col = LESSON_COLORS[(lesson.num - 1) % LESSON_COLORS.length]

            return (
              <motion.div key={lesson.num} variants={fadeInUp}>
                <Card
                  className={`relative overflow-hidden cursor-pointer transition-all duration-300 hover:shadow-lg hover:-translate-y-1 border-0 ${
                    unlocked ? '' : 'opacity-60 cursor-not-allowed'
                  }`}
                  onClick={() => unlocked && setSelectedLesson(lesson.num)}
                >
                  {/* Top color bar */}
                  <div
                    className={`h-2 w-full bg-gradient-to-l ${col.gradient}`}
                  />

                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div
                        className="w-12 h-12 rounded-xl flex items-center justify-center text-white font-bold text-lg shadow-sm"
                        style={{ backgroundColor: col.bg }}
                      >
                        {lesson.num}
                      </div>
                      <div className="flex flex-col items-center gap-1">
                        {completed && (
                          <div className="w-7 h-7 rounded-full bg-emerald-500 flex items-center justify-center">
                            <CheckCircle className="w-5 h-5 text-white" />
                          </div>
                        )}
                        {!unlocked && (
                          <Lock className="w-6 h-6 text-gray-400" />
                        )}
                        <div className="flex gap-0.5">
                          {[1, 2, 3].map(s => (
                            <Star
                              key={s}
                              className={`w-3.5 h-3.5 ${s <= stars ? 'text-amber-400 fill-amber-400' : 'text-gray-200'}`}
                            />
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Chinese title - large */}
                    <h3
                      className="text-2xl font-bold mb-1 leading-tight"
                      style={{ color: col.dark }}
                    >
                      {lesson.titleZh}
                    </h3>

                    {/* Arabic title */}
                    <p className="text-sm text-gray-600 mb-3 leading-relaxed">
                      {lesson.titleAr}
                    </p>

                    {/* Word count */}
                    <div className="flex items-center justify-between">
                      <Badge
                        variant="secondary"
                        className="text-xs"
                        style={{ backgroundColor: col.light, color: col.dark }}
                      >
                        📝 {lesson.words.length} كلمة
                      </Badge>
                      {unlocked && (
                        <ChevronRight
                          className="w-5 h-5 transition-transform group-hover:translate-x-1"
                          style={{ color: col.bg }}
                        />
                      )}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )
          })}
        </motion.div>

        {/* Stats summary */}
        <motion.div
          className="mt-8 grid grid-cols-3 gap-3"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card className="text-center p-4 border-0 bg-gradient-to-b from-amber-50 to-white">
            <Trophy className="w-6 h-6 mx-auto mb-1 text-amber-500" />
            <div className="text-xl font-bold text-amber-600">{totalXP}</div>
            <div className="text-xs text-gray-500">إجمالي XP</div>
          </Card>
          <Card className="text-center p-4 border-0 bg-gradient-to-b from-red-50 to-white">
            <Flame className="w-6 h-6 mx-auto mb-1 text-red-500" />
            <div className="text-xl font-bold text-red-600">{streak}</div>
            <div className="text-xs text-gray-500">أيام متتالية</div>
          </Card>
          <Card className="text-center p-4 border-0 bg-gradient-to-b from-blue-50 to-white">
            <Target className="w-6 h-6 mx-auto mb-1 text-blue-500" />
            <div className="text-xl font-bold text-blue-600">
              {hsk1AllWords.filter(w => completedLessons.has(w.lesson)).length}
            </div>
            <div className="text-xs text-gray-500">كلمة مُنجزة</div>
          </Card>
        </motion.div>
      </div>
    )
  }

  // ─── RENDER: Inside a Lesson ───────────────────────────────
  return (
    <div className="w-full max-w-4xl mx-auto px-4 pb-8" dir="rtl">
      <AnimatePresence mode="wait">
        <motion.div
          key={selectedLesson}
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: 30 }}
          transition={{ duration: 0.3 }}
        >
          {/* Lesson Header */}
          <div className="mb-6">
            <Button
              variant="ghost"
              onClick={goBack}
              className="mb-3 text-gray-500 hover:text-gray-700 -mr-2"
            >
              <ArrowRight className="w-4 h-4 ml-1" />
              العودة للدروس
            </Button>

            <div className="flex items-center gap-3 mb-2">
              <div
                className="w-14 h-14 rounded-2xl flex items-center justify-center text-white font-bold text-xl shadow-md"
                style={{ backgroundColor: colors.bg }}
              >
                {selectedLesson}
              </div>
              <div className="flex-1">
                <h2 className="text-3xl sm:text-4xl font-bold" style={{ color: colors.dark }}>
                  {currentLesson?.titleZh}
                </h2>
                <p className="text-gray-500 text-sm mt-0.5">{currentLesson?.titleAr}</p>
              </div>
              <div className="flex items-center gap-2">
                <Badge className="bg-emerald-100 text-emerald-700 text-xs">
                  📝 {currentWords.length} كلمة
                </Badge>
                {completedLessons.has(selectedLesson) && (
                  <Badge className="bg-amber-100 text-amber-700 text-xs gap-1">
                    <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                    {lessonStars[selectedLesson] || 0}/3
                  </Badge>
                )}
              </div>
            </div>

            {/* Mini progress bar for vocab */}
            <div className="mt-3">
              <div className="flex items-center justify-between mb-1 text-xs text-gray-400">
                <span>المفردات المُراجعة</span>
                <span>{Math.min(reviewedWords.size, currentWords.length)}/{currentWords.length}</span>
              </div>
              <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                <motion.div
                  className="h-full rounded-full bg-gradient-to-l from-emerald-400 to-emerald-500"
                  initial={{ width: 0 }}
                  animate={{
                    width: `${currentWords.length > 0 ? (Math.min(reviewedWords.size, currentWords.length) / currentWords.length) * 100 : 0}%`
                  }}
                  transition={{ duration: 0.5 }}
                />
              </div>
            </div>
          </div>

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-4 mb-6 bg-gray-100/80 p-1 h-auto rounded-xl">
              <TabsTrigger
                value="vocab"
                className="rounded-lg text-xs sm:text-sm py-2 data-[state=active]:bg-white data-[state=active]:shadow-sm gap-1"
              >
                <BookOpen className="w-3.5 h-3.5 hidden sm:block" />
                المفردات
              </TabsTrigger>
              <TabsTrigger
                value="conv"
                className="rounded-lg text-xs sm:text-sm py-2 data-[state=active]:bg-white data-[state=active]:shadow-sm gap-1"
              >
                <MessageCircle className="w-3.5 h-3.5 hidden sm:block" />
                المحادثات
              </TabsTrigger>
              <TabsTrigger
                value="grammar"
                className="rounded-lg text-xs sm:text-sm py-2 data-[state=active]:bg-white data-[state=active]:shadow-sm gap-1"
              >
                <GraduationCap className="w-3.5 h-3.5 hidden sm:block" />
                القواعد
              </TabsTrigger>
              <TabsTrigger
                value="exercises"
                className="rounded-lg text-xs sm:text-sm py-2 data-[state=active]:bg-white data-[state=active]:shadow-sm gap-1"
              >
                <PenTool className="w-3.5 h-3.5 hidden sm:block" />
                التمارين
              </TabsTrigger>
            </TabsList>

            {/* ─── TAB: Vocabulary ────────────────────────── */}
            <TabsContent value="vocab">
              <motion.div
                className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3"
                variants={staggerContainer}
                initial="initial"
                animate="animate"
              >
                {currentWords.map((word, idx) => {
                  const wordKey = `${word.chinese}-${word.pinyin}`
                  const isFlipped = flippedCards.has(wordKey)
                  const isReviewed = reviewedWords.has(wordKey)

                  return (
                    <motion.div
                      key={wordKey}
                      variants={scaleIn}
                      className="perspective-600"
                    >
                      <motion.div
                        className="relative w-full cursor-pointer"
                        style={{ minHeight: '140px', transformStyle: 'preserve-3d' }}
                        onClick={() => toggleFlip(wordKey)}
                        animate={{ rotateY: isFlipped ? 180 : 0 }}
                        transition={{ duration: 0.4, type: 'spring', stiffness: 200, damping: 25 }}
                      >
                        {/* Front */}
                        <div
                          className="absolute inset-0 rounded-xl p-3 flex flex-col items-center justify-center border-2 bg-white shadow-sm"
                          style={{
                            backfaceVisibility: 'hidden',
                            borderColor: isReviewed ? colors.bg : '#E5E7EB',
                          }}
                        >
                          {isReviewed && (
                            <div className="absolute top-1.5 left-1.5 w-4 h-4 rounded-full bg-emerald-500 flex items-center justify-center">
                              <CheckCircle className="w-3 h-3 text-white" />
                            </div>
                          )}
                          <button
                            className="absolute top-1.5 right-1.5 w-6 h-6 rounded-full flex items-center justify-center hover:bg-gray-100 transition-colors"
                            onClick={(e) => { e.stopPropagation(); speak(word.chinese) }}
                          >
                            <Volume2 className="w-3.5 h-3.5 text-gray-400" />
                          </button>
                          <span
                            className="text-3xl sm:text-4xl font-bold leading-tight mb-1"
                            style={{ color: colors.dark }}
                          >
                            {word.chinese}
                          </span>
                          <span className="text-xs text-gray-400">{word.pinyin}</span>
                        </div>

                        {/* Back */}
                        <div
                          className="absolute inset-0 rounded-xl p-3 flex flex-col items-center justify-center border-2 shadow-sm"
                          style={{
                            backfaceVisibility: 'hidden',
                            transform: 'rotateY(180deg)',
                            backgroundColor: colors.light,
                            borderColor: colors.bg,
                          }}
                        >
                          <span
                            className="text-2xl sm:text-3xl font-bold leading-tight mb-2"
                            style={{ color: colors.dark }}
                          >
                            {word.chinese}
                          </span>
                          <span className="text-sm font-medium text-gray-700 mb-0.5">{word.pinyin}</span>
                          <span className="text-xs text-gray-500 font-medium">{word.arabic}</span>
                        </div>
                      </motion.div>
                    </motion.div>
                  )
                })}
              </motion.div>

              {/* Vocab review stats */}
              {reviewedWords.size > 0 && (
                <motion.div
                  className="mt-6 text-center"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                >
                  <Badge className="bg-emerald-100 text-emerald-700 text-sm px-4 py-1.5 gap-1.5">
                    <Sparkles className="w-4 h-4" />
                    +{reviewedWords.size * XP_REWARDS.vocabReview} XP — {reviewedWords.size} كلمة مُراجعة
                  </Badge>
                </motion.div>
              )}
            </TabsContent>

            {/* ─── TAB: Conversations ─────────────────────── */}
            <TabsContent value="conv">
              {currentContent && currentContent.conversations.length > 0 && (
                <>
                  {/* Conversation selector */}
                  {currentContent.conversations.length > 1 && (
                    <div className="flex gap-2 mb-4 flex-wrap">
                      {currentContent.conversations.map((_, idx) => (
                        <Button
                          key={idx}
                          variant={activeConv === idx ? 'default' : 'outline'}
                          size="sm"
                          onClick={() => { setActiveConv(idx); setConvRevealIndex(0); }}
                          className={
                            activeConv === idx
                              ? `bg-gradient-to-l ${colors.gradient} text-white border-0 rounded-lg`
                              : 'rounded-lg'
                          }
                        >
                          محادثة {idx + 1}
                        </Button>
                      ))}
                    </div>
                  )}

                  {/* Conversation display */}
                  <Card className="border-0 shadow-sm bg-gradient-to-b from-gray-50 to-white overflow-hidden">
                    <CardContent className="p-4 sm:p-6">
                      <div className="space-y-3">
                        {currentContent.conversations[activeConv]?.map((turn, idx) => {
                          const isRevealed = idx <= convRevealIndex
                          const isA = turn.speaker === 'A'

                          return (
                            <motion.div
                              key={idx}
                              initial={{ opacity: 0, y: 10, x: isA ? 20 : -20 }}
                              animate={isRevealed ? { opacity: 1, y: 0, x: 0 } : {}}
                              transition={{ delay: isRevealed ? 0.1 : 0, duration: 0.3 }}
                              className={`flex flex-col ${isA ? 'items-start' : 'items-end'}`}
                            >
                              <span className="text-xs font-medium text-gray-400 mb-1 px-1">
                                {turn.name}
                              </span>
                              <div
                                className={`max-w-[85%] rounded-2xl px-4 py-3 ${
                                  isA
                                    ? `rounded-br-sm text-white`
                                    : 'rounded-bl-sm bg-white border border-gray-100 shadow-sm'
                                }`}
                                style={isA ? { backgroundColor: colors.bg } : {}}
                              >
                                <div className="flex items-start gap-2">
                                  <span className={`text-lg sm:text-xl font-bold leading-relaxed ${isA ? 'text-white' : ''}`} style={!isA ? { color: colors.dark } : {}}>
                                    {turn.hanzi}
                                  </span>
                                  <button
                                    className="flex-shrink-0 mt-1 w-6 h-6 rounded-full flex items-center justify-center hover:bg-black/5 transition-colors"
                                    onClick={() => speak(turn.hanzi)}
                                  >
                                    <Volume2 className={`w-3.5 h-3.5 ${isA ? 'text-white/70' : 'text-gray-400'}`} />
                                  </button>
                                </div>
                                <p className={`text-xs mt-1.5 ${isA ? 'text-white/70' : 'text-gray-400'}`}>
                                  {turn.pinyin}
                                </p>
                                <p className={`text-sm mt-1 font-medium ${isA ? 'text-white/90' : 'text-gray-600'}`}>
                                  {turn.arabic}
                                </p>
                              </div>
                            </motion.div>
                          )
                        })}
                      </div>

                      {/* Reveal next / replay */}
                      <div className="mt-4 flex gap-2 justify-center">
                        {convRevealIndex < (currentContent.conversations[activeConv]?.length || 0) - 1 ? (
                          <Button
                            size="sm"
                            className={`bg-gradient-to-l ${colors.gradient} text-white rounded-lg`}
                            onClick={() => setConvRevealIndex(prev => prev + 1)}
                          >
                            التالي <ArrowLeft className="w-4 h-4 mr-1" />
                          </Button>
                        ) : (
                          <Button
                            size="sm"
                            variant="outline"
                            className="rounded-lg"
                            onClick={() => { setConvRevealIndex(0); addXP(10) }}
                          >
                            <RotateCcw className="w-4 h-4 ml-1" />
                            إعادة المحادثة (+10 XP)
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </>
              )}
            </TabsContent>

            {/* ─── TAB: Grammar ───────────────────────────── */}
            <TabsContent value="grammar">
              {currentContent && currentContent.grammar.length > 0 && (
                <motion.div className="space-y-4" variants={staggerContainer} initial="initial" animate="animate">
                  {currentContent.grammar.map((rule, idx) => (
                    <motion.div key={idx} variants={fadeInUp}>
                      <Card className="border-0 shadow-sm overflow-hidden">
                        {/* Color accent top */}
                        <div className={`h-1 bg-gradient-to-l ${colors.gradient}`} />
                        <CardContent className="p-5">
                          <div className="flex items-center gap-3 mb-3">
                            <div
                              className="w-8 h-8 rounded-lg flex items-center justify-center text-white text-sm font-bold"
                              style={{ backgroundColor: colors.bg }}
                            >
                              {idx + 1}
                            </div>
                            <h4 className="text-lg font-bold text-gray-800">{rule.title}</h4>
                          </div>

                          <p className="text-sm text-gray-600 mb-4 leading-relaxed">{rule.description}</p>

                          {/* Pattern box */}
                          <div
                            className="rounded-xl p-4 mb-3 text-center"
                            style={{ backgroundColor: colors.light }}
                          >
                            <p className="text-xs text-gray-400 mb-1">النمط</p>
                            <p className="font-mono text-sm font-bold" style={{ color: colors.dark }}>
                              {rule.pattern}
                            </p>
                          </div>

                          {/* Example */}
                          <div className="bg-gray-50 rounded-xl p-4">
                            <p className="text-xs text-gray-400 mb-2">مثال</p>
                            <div className="flex items-start gap-2 justify-between">
                              <div>
                                <p className="text-lg font-bold text-gray-800">{rule.example}</p>
                                <p className="text-sm text-gray-500 mt-0.5">{rule.exampleAr}</p>
                              </div>
                              <button
                                className="flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center hover:bg-gray-200 transition-colors"
                                onClick={() => speak(rule.example)}
                              >
                                <Volume2 className="w-4 h-4 text-gray-400" />
                              </button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </motion.div>
              )}
            </TabsContent>

            {/* ─── TAB: Exercises ─────────────────────────── */}
            <TabsContent value="exercises">
              {currentContent && (
                <>
                  {/* Exercise mode toggle */}
                  <div className="flex gap-2 mb-4">
                    <Button
                      variant={exerciseMode === 'quiz' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setExerciseMode('quiz')}
                      className={exerciseMode === 'quiz' ? `bg-gradient-to-l ${colors.gradient} text-white rounded-lg border-0` : 'rounded-lg'}
                    >
                      📋 اختبار
                    </Button>
                    <Button
                      variant={exerciseMode === 'match' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => { setExerciseMode('match'); handleResetMatch() }}
                      className={exerciseMode === 'match' ? `bg-gradient-to-l ${colors.gradient} text-white rounded-lg border-0` : 'rounded-lg'}
                    >
                      🔗 مطابقة
                    </Button>
                  </div>

                  {exerciseMode === 'quiz' && (
                    <motion.div className="space-y-5" variants={staggerContainer} initial="initial" animate="animate">
                      {currentContent.exercises.map((q, qIdx) => {
                        const isAnswered = showResults
                        const selected = answers[qIdx]
                        const isCorrect = selected === q.correct

                        return (
                          <motion.div key={qIdx} variants={fadeInUp}>
                            <Card
                              className={`border-0 shadow-sm overflow-hidden transition-all duration-300 ${
                                isAnswered
                                  ? isCorrect ? 'ring-2 ring-emerald-400 bg-emerald-50/50' : 'ring-2 ring-red-300 bg-red-50/50'
                                  : ''
                              }`}
                            >
                              <CardContent className="p-4 sm:p-5">
                                <div className="flex items-start gap-3 mb-3">
                                  <div
                                    className="w-7 h-7 rounded-lg flex items-center justify-center text-white text-xs font-bold flex-shrink-0"
                                    style={{ backgroundColor: colors.bg }}
                                  >
                                    {qIdx + 1}
                                  </div>
                                  <p className="text-sm font-bold text-gray-800 leading-relaxed pt-0.5">
                                    {q.zh}
                                  </p>
                                  {isAnswered && (
                                    <div className="flex-shrink-0">
                                      {isCorrect ? (
                                        <motion.div {...starPop}>
                                          <CheckCircle className="w-6 h-6 text-emerald-500" />
                                        </motion.div>
                                      ) : (
                                        <div className="w-6 h-6 rounded-full bg-red-500 flex items-center justify-center">
                                          <span className="text-white text-xs font-bold">✕</span>
                                        </div>
                                      )}
                                    </div>
                                  )}
                                </div>

                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                                  {q.options.map((opt, optIdx) => {
                                    const isSelected = selected === optIdx
                                    const isCorrectOpt = q.correct === optIdx
                                    let optStyle = 'border-gray-100 bg-white hover:border-gray-200 hover:bg-gray-50'

                                    if (isAnswered) {
                                      if (isCorrectOpt) {
                                        optStyle = 'border-emerald-400 bg-emerald-100 text-emerald-800'
                                      } else if (isSelected && !isCorrectOpt) {
                                        optStyle = 'border-red-300 bg-red-100 text-red-800'
                                      } else {
                                        optStyle = 'border-gray-100 bg-gray-50 opacity-60'
                                      }
                                    } else if (isSelected) {
                                      optStyle = `border-[${colors.bg}] text-white`
                                    }

                                    return (
                                      <button
                                        key={optIdx}
                                        className={`px-4 py-2.5 rounded-xl border-2 text-sm text-right transition-all duration-200 ${optStyle}`}
                                        style={!isAnswered && isSelected ? { backgroundColor: colors.bg, borderColor: colors.bg, color: '#fff' } : {}}
                                        onClick={() => !isAnswered && setAnswers(prev => ({ ...prev, [qIdx]: optIdx }))}
                                        disabled={isAnswered}
                                      >
                                        {opt}
                                      </button>
                                    )
                                  })}
                                </div>
                              </CardContent>
                            </Card>
                          </motion.div>
                        )
                      })}

                      {/* Action buttons */}
                      <div className="flex gap-3 justify-center mt-6">
                        {!showResults ? (
                          <Button
                            size="lg"
                            className={`bg-gradient-to-l ${colors.gradient} text-white rounded-xl px-8 shadow-lg shadow-blue-200/50`}
                            onClick={handleCheckAnswers}
                            disabled={Object.keys(answers).length < currentContent.exercises.length}
                          >
                            <Target className="w-5 h-5 ml-2" />
                            تحقق من الإجابات
                          </Button>
                        ) : (
                          <>
                            {/* Results display */}
                            <motion.div
                              className="text-center mb-4"
                              initial={{ opacity: 0, scale: 0.8 }}
                              animate={{ opacity: 1, scale: 1 }}
                              transition={{ type: 'spring' }}
                            >
                              {(() => {
                                const total = currentContent.exercises.length
                                let correct = 0
                                currentContent.exercises.forEach((q, i) => {
                                  if (answers[i] === q.correct) correct++
                                })
                                const stars = calculateStars(correct, total)
                                const pct = Math.round((correct / total) * 100)

                                return (
                                  <div className="bg-gradient-to-b from-amber-50 to-white rounded-2xl p-6 border border-amber-100">
                                    <div className="flex justify-center gap-1 mb-3">
                                      {[1, 2, 3].map(s => (
                                        <motion.div
                                          key={s}
                                          initial={{ scale: 0, rotate: -180 }}
                                          animate={{ scale: s <= stars ? 1 : 0.8, rotate: 0 }}
                                          transition={{ delay: s * 0.2, type: 'spring' }}
                                        >
                                          <Star
                                            className={`w-10 h-10 ${s <= stars ? 'text-amber-400 fill-amber-400' : 'text-gray-200'}`}
                                          />
                                        </motion.div>
                                      ))}
                                    </div>
                                    <p className="text-2xl font-bold text-gray-800">{pct}%</p>
                                    <p className="text-sm text-gray-500 mt-1">{correct} من {total} صحيح</p>
                                    {completedLessons.has(selectedLesson) && (
                                      <p className="text-xs text-emerald-600 mt-2 font-medium">
                                        🎉 أحسنت! حصلت على +{XP_REWARDS.lessonComplete + (stars * 20)} XP
                                      </p>
                                    )}
                                  </div>
                                )
                              })()}
                            </motion.div>

                            <Button
                              variant="outline"
                              size="lg"
                              className="rounded-xl px-6"
                              onClick={handleResetExercises}
                            >
                              <RotateCcw className="w-4 h-4 ml-1" />
                              إعادة
                            </Button>
                          </>
                        )}
                      </div>
                    </motion.div>
                  )}

                  {exerciseMode === 'match' && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                    >
                      <Card className="border-0 shadow-sm bg-gradient-to-b from-gray-50 to-white">
                        <CardContent className="p-4 sm:p-6">
                          <p className="text-sm text-gray-500 text-center mb-4">
                            🔗 طابق كل كلمة صينية بمعناها العربي
                          </p>

                          <div className="grid grid-cols-2 gap-6">
                            {/* Chinese words */}
                            <div className="space-y-2">
                              <p className="text-xs font-bold text-gray-400 mb-2 text-center">中文</p>
                              {matchPairs.map((pair, idx) => {
                                const isMatched = matchMatched.has(pair.zh)
                                const isError = matchErrors.has(pair.zh)
                                const isSelected = matchSelected?.side === 'zh' && matchSelected?.idx === idx

                                return (
                                  <motion.button
                                    key={`zh-${idx}`}
                                    className={`w-full p-3 rounded-xl border-2 text-center text-lg font-bold transition-all duration-200 ${
                                      isMatched
                                        ? 'border-emerald-400 bg-emerald-100 text-emerald-700'
                                        : isError
                                        ? 'border-red-400 bg-red-100 text-red-700'
                                        : isSelected
                                        ? 'border-blue-400 bg-blue-100 text-blue-700'
                                        : 'border-gray-200 bg-white hover:border-blue-300 text-gray-800'
                                    }`}
                                    onClick={() => handleMatchSelect('zh', idx, pair.zh)}
                                    disabled={isMatched}
                                    whileTap={{ scale: 0.97 }}
                                  >
                                    {pair.zh}
                                  </motion.button>
                                )
                              })}
                            </div>

                            {/* Arabic words (shuffled) */}
                            <div className="space-y-2">
                              <p className="text-xs font-bold text-gray-400 mb-2 text-center">العربية</p>
                              {(() => {
                                const shuffledAr = [...matchPairs]
                                  .map((p, i) => ({ text: p.ar, origIdx: i }))
                                  .sort(() => Math.random() - 0.5)
                                return shuffledAr.map((item, idx) => {
                                  const isMatched = matchMatched.has(item.text)
                                  const isError = matchErrors.has(item.text)
                                  const isSelected = matchSelected?.side === 'ar' && matchSelected?.idx === item.origIdx

                                  return (
                                    <motion.button
                                      key={`ar-${idx}`}
                                      className={`w-full p-3 rounded-xl border-2 text-center text-sm font-medium transition-all duration-200 ${
                                        isMatched
                                          ? 'border-emerald-400 bg-emerald-100 text-emerald-700'
                                          : isError
                                          ? 'border-red-400 bg-red-100 text-red-700'
                                          : isSelected
                                          ? 'border-blue-400 bg-blue-100 text-blue-700'
                                          : 'border-gray-200 bg-white hover:border-blue-300 text-gray-700'
                                      }`}
                                      onClick={() => handleMatchSelect('ar', item.origIdx, item.text)}
                                      disabled={isMatched}
                                      whileTap={{ scale: 0.97 }}
                                    >
                                      {item.text}
                                    </motion.button>
                                  )
                                })
                              })()}
                            </div>
                          </div>

                          {matchPairs.length > 0 && matchMatched.size === matchPairs.length && (
                            <motion.div
                              className="mt-6 text-center"
                              initial={{ opacity: 0, scale: 0.8 }}
                              animate={{ opacity: 1, scale: 1 }}
                            >
                              <p className="text-lg font-bold text-emerald-600 mb-2">🎉 أحسنت!</p>
                              <Button
                                variant="outline"
                                size="sm"
                                className="rounded-lg"
                                onClick={handleResetMatch}
                              >
                                <RotateCcw className="w-4 h-4 ml-1" />
                                إعادة
                              </Button>
                            </motion.div>
                          )}
                        </CardContent>
                      </Card>
                    </motion.div>
                  )}
                </>
              )}
            </TabsContent>
          </Tabs>
        </motion.div>
      </AnimatePresence>
    </div>
  )
}
