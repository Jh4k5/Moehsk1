'use client'

import React, { useState, useMemo, useCallback } from 'react'
import { hsk1Lessons, hsk1AllWords, type HSK1Word } from '@/data/hsk1NewCurriculum'
import { vocabulary, type VocabWord } from '@/data/vocabulary'
import { useLearningStore } from '@/lib/store'
import { speak } from '@/lib/helpers'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { ScrollArea } from '@/components/ui/scroll-area'
import { motion, AnimatePresence } from 'framer-motion'
import {
  BookOpen, Volume2, ChevronLeft, ChevronRight, Star, Check,
  Search, BookmarkPlus, Zap, Eye, EyeOff, Layers,
  ArrowUpDown, Grid3X3, List, Sparkles, Trophy, Clock,
  GraduationCap, Heart, Target, Filter
} from 'lucide-react'
import QuizletFlashcard from '@/components/QuizletFlashcard'

// ─── Semantic Category Map ──────────────────────────────────
const SEMANTIC_CATEGORIES = [
  { value: 'all', label: 'الكل', icon: Layers },
  { value: 'greetings', label: 'التحيات', icon: Sparkles },
  { value: 'family', label: 'العائلة', icon: Heart },
  { value: 'people', label: 'الأشخاص', icon: GraduationCap },
  { value: 'food', label: 'الطعام والشراب', icon: Target },
  { value: 'places', label: 'الأماكن', icon: MapPinIcon },
  { value: 'time', label: 'الوقت', icon: Clock },
  { value: 'daily', label: 'الحياة اليومية', icon: Zap },
  { value: 'shopping', label: 'التسوق', icon: ShoppingIcon },
  { value: 'weather', label: 'الطقس', icon: WeatherIcon },
  { value: 'study', label: 'الدراسة', icon: BookOpen },
  { value: 'transport', label: 'المواصلات', icon: TransportIcon },
  { value: 'body', label: 'الصحة', icon: BodyIcon },
] as const

type SemanticCategory = typeof SEMANTIC_CATEGORIES[number]['value']

// Category keyword mapping (Chinese chars & Arabic keywords)
const CATEGORY_KEYWORDS: Record<string, string[]> = {
  greetings: ['你好', '谢谢', '再见', '不客气', '没关系', '没事', '高兴', '认识', '喂', '请问', 'مرحبا', 'شكرا', 'وداعا', 'العفو', 'لا بأس', 'سعيد', 'معرفتك', 'ألو', 'عذرا'],
  family: ['爸爸', '妈妈', '哥哥', '姐姐', '妹妹', '弟弟', '儿子', '女儿', '孩子', '家', '家人', '口', '岁', 'أب', 'أم', 'أخ', 'أخت', 'ابن', 'ابنة', 'طفل', 'عائلة', 'عمر'],
  people: ['人', '大家', '们', '老师', '学生', '同学', '朋友', '先生', '女士', '服务员', '售货员', '小朋友', '大学生', '中学生', '小学生', '医生', '病人', '女朋友', '男朋友', 'شخص', 'الجميع', 'معلم', 'طالب', 'زميل', 'صديق', 'سيد', 'سيدة', 'نادل', 'بائع', 'طفل', 'طبيب', 'مريض'],
  food: ['吃', '饭', '菜', '面条', '饺子', '包子', '米饭', '牛奶', '好吃', '早饭', '午饭', '晚饭', '面包', '鸡蛋', '茶', '喝', '水', '饭', '杯子', '杯', 'يأكل', 'طعام', 'نودلز', 'حليب', 'لذيذ', 'إفطار', 'غداء', 'عشاء', 'خبز', 'بيضة', 'شاي', 'يشرب', 'ماء', 'كوب'],
  places: ['哪儿', '哪里', '这里', '那里', '这边', '那边', '前边', '外边', '外', '前', '学校', '医院', '电影院', '书店', '饭店', '商店', '店', '超市', '公司', '大学', '机场', '房间', '里', '家', '在', 'أين', 'هنا', 'هناك', 'مدرسة', 'مستشفى', 'سينما', 'مكتبة', 'مطعم', 'متجر', 'سوبر', 'شركة', 'جامعة', 'مطار', 'غرفة', 'في'],
  time: ['今天', '明天', '昨天', '早上', '上午', '中午', '下午', '晚上', '时间', '小时', '分钟', '分', '现在', '年', '时候', '月', '日', '号', '星期', '半', '点', 'اليوم', 'غدا', 'أمس', 'صباحا', 'ظهر', 'مساء', 'وقت', 'ساعة', 'دقيقة', 'الآن', 'سنة', 'شهر', 'يوم', 'أسبوع'],
  daily: ['做', '工作', '上班', '下班', '上课', '下课', '起床', '睡觉', '看', '玩', '想', '喜欢', '看电视', '读书', '写字', '唱歌', '说话', '打电话', '看书', '手机', '电脑', '电话', '衣服', '穿', '买', '东西', '问题', '问', '说', '知道', '可以', '要', '请', '坐', '给', '一会儿', '一下', '一半', '工作', 'وظيفة', 'ينام', 'يستيقظ', 'يرى', 'يلعب', 'يحب', 'يريد', 'يعرف'],
  shopping: ['买', '钱', '块', '元', '便宜', '贵', '商店', '超市', '怎么', '怎么样', '衣服', '件', '这', '那', '那个', '这个', '这些', '那些', '哪些', '哪个', '有些', '有的', '卖', 'يبيع', 'يشتري', 'نقود', 'رخيص', 'غالي'],
  weather: ['天气', '下雨', '雨', '冷', '热', '雪', '觉得', '有点儿', '一点儿', 'طقس', 'يمطر', 'مطر', 'بارد', 'حار', 'ثلج', 'يشتعر'],
  study: ['学', '学习', '书', '课', '字', '读', '第', '本', '年', '小学', '中学', '上学', '考试', 'يتعلم', 'كتاب', 'درس', 'حرف', 'يكتب', 'يقرأ'],
  transport: ['去', '到', '车', '出租车', '火车', '飞机', '开车', '哪儿', '坐', 'يذهب', 'يصل', 'سيارة', 'تاكسي', 'قطار', 'طائرة', 'يقود'],
  body: ['生病', '病', '看', '医生', '药', '回', '再', '不要', '说话', '听见', '听见', 'مرض', 'طبيب', 'دواء', 'يعود', 'مرة أخرى'],
}

function categorizeWord(w: HSK1Word): SemanticCategory[] {
  const matched: SemanticCategory[] = []
  for (const [cat, keywords] of Object.entries(CATEGORY_KEYWORDS)) {
    for (const kw of keywords) {
      if (w.chinese.includes(kw) || w.arabic.includes(kw)) {
        matched.push(cat as SemanticCategory)
        break
      }
    }
  }
  return matched.length > 0 ? matched : ['daily']
}

// ─── Fallback Icons ─────────────────────────────────────────
function MapPinIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z" /><circle cx="12" cy="10" r="3" />
    </svg>
  )
}
function ShoppingIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="8" cy="21" r="1" /><circle cx="19" cy="21" r="1" /><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12" />
    </svg>
  )
}
function WeatherIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z" />
    </svg>
  )
}
function TransportIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2" /><circle cx="7" cy="17" r="2" /><path d="M9 17h6" /><circle cx="17" cy="17" r="2" />
    </svg>
  )
}
function BodyIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
    </svg>
  )
}

// ─── Word Status ────────────────────────────────────────────
type WordStatus = 'mastered' | 'learning' | 'new'

function getWordStatus(word: HSK1Word, learnedWords: number[], bookmarkedWords: number[]): WordStatus {
  // Match new curriculum word to old vocabulary by chinese text
  const oldWord = vocabulary.find(v => v.zh === word.chinese)
  if (oldWord) {
    if (learnedWords.includes(oldWord.id)) return 'mastered'
    if (bookmarkedWords.includes(oldWord.id)) return 'learning'
  }
  return 'new'
}

// ─── Sort Options ───────────────────────────────────────────
type SortOption = 'lesson' | 'alpha-zh' | 'alpha-ar' | 'status'

const SORT_OPTIONS: { value: SortOption; label: string }[] = [
  { value: 'lesson', label: 'حسب الدرس' },
  { value: 'alpha-zh', label: 'أبجدي (صيني)' },
  { value: 'alpha-ar', label: 'أبجدي (عربي)' },
  { value: 'status', label: 'حسب الحالة' },
]

// ─── Status config ──────────────────────────────────────────
const STATUS_CONFIG: Record<WordStatus, { label: string; color: string; bg: string; border: string; icon: React.FC<{ className?: string }> }> = {
  mastered: {
    label: 'تم الإتقان',
    color: 'text-emerald-700',
    bg: 'bg-emerald-50',
    border: 'border-emerald-200',
    icon: Check,
  },
  learning: {
    label: 'قيد التعلم',
    color: 'text-amber-700',
    bg: 'bg-amber-50',
    border: 'border-amber-200',
    icon: Star,
  },
  new: {
    label: 'جديد',
    color: 'text-gray-500',
    bg: 'bg-gray-50',
    border: 'border-gray-200',
    icon: Sparkles,
  },
}

// ─── Main Component ─────────────────────────────────────────
export default function VocabularySection() {
  const store = useLearningStore()

  // Local state
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedLesson, setSelectedLesson] = useState<number>(0) // 0 = all
  const [selectedCategory, setSelectedCategory] = useState<SemanticCategory>('all')
  const [sortBy, setSortBy] = useState<SortOption>('lesson')
  const [hideMastered, setHideMastered] = useState(false)
  const [hideNew, setHideNew] = useState(false)
  const [showPinyin, setShowPinyin] = useState(true)
  const [viewMode, setViewMode] = useState<'grid' | 'flashcards' | 'favorites' | 'quizlet' | 'list'>('grid')
  const [expandedCard, setExpandedCard] = useState<string | null>(null)

  // ─── Compute category map for all words ──────────────────
  const wordCategoryMap = useMemo(() => {
    const map = new Map<string, SemanticCategory[]>()
    for (const w of hsk1AllWords) {
      map.set(w.chinese, categorizeWord(w))
    }
    return map
  }, [])

  // ─── Filtered & sorted words ─────────────────────────────
  const filteredWords = useMemo(() => {
    let words = [...hsk1AllWords]

    // Filter by lesson
    if (selectedLesson > 0) {
      words = words.filter(w => w.lesson === selectedLesson)
    }

    // Filter by category
    if (selectedCategory !== 'all') {
      words = words.filter(w => {
        const cats = wordCategoryMap.get(w.chinese) || []
        return cats.includes(selectedCategory)
      })
    }

    // Filter by search
    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase()
      words = words.filter(w =>
        w.chinese.includes(searchQuery.trim()) ||
        w.pinyin.toLowerCase().includes(q) ||
        w.arabic.includes(searchQuery.trim())
      )
    }

    // Filter by status
    if (hideMastered) {
      words = words.filter(w => getWordStatus(w, store.learnedWords, store.bookmarkedWords) !== 'mastered')
    }
    if (hideNew) {
      words = words.filter(w => getWordStatus(w, store.learnedWords, store.bookmarkedWords) !== 'new')
    }

    // Sort
    switch (sortBy) {
      case 'lesson':
        words.sort((a, b) => a.lesson - b.lesson)
        break
      case 'alpha-zh':
        words.sort((a, b) => a.chinese.localeCompare(b.chinese, 'zh'))
        break
      case 'alpha-ar':
        words.sort((a, b) => a.arabic.localeCompare(b.arabic, 'ar'))
        break
      case 'status': {
        const order: Record<WordStatus, number> = { new: 0, learning: 1, mastered: 2 }
        words.sort((a, b) => {
          const sa = getWordStatus(a, store.learnedWords, store.bookmarkedWords)
          const sb = getWordStatus(b, store.learnedWords, store.bookmarkedWords)
          return order[sa] - order[sb]
        })
        break
      }
    }

    return words
  }, [selectedLesson, selectedCategory, searchQuery, sortBy, hideMastered, hideNew, store.learnedWords, store.bookmarkedWords, wordCategoryMap])

  // ─── Statistics ──────────────────────────────────────────
  const stats = useMemo(() => {
    const base = selectedLesson > 0
      ? hsk1AllWords.filter(w => w.lesson === selectedLesson)
      : hsk1AllWords

    let total = base.length
    let mastered = 0
    let learning = 0
    let newCount = 0

    for (const w of base) {
      const status = getWordStatus(w, store.learnedWords, store.bookmarkedWords)
      if (status === 'mastered') mastered++
      else if (status === 'learning') learning++
      else newCount++
    }

    return { total, mastered, learning, newCount, percent: total > 0 ? Math.round((mastered / total) * 100) : 0 }
  }, [selectedLesson, store.learnedWords, store.bookmarkedWords])

  // ─── Bookmarked words for favorites tab ──────────────────
  const bookmarkedWords = useMemo(() => {
    return hsk1AllWords.filter(w => {
      const oldWord = vocabulary.find(v => v.zh === w.chinese)
      return oldWord && store.bookmarkedWords.includes(oldWord.id)
    })
  }, [store.bookmarkedWords])

  // ─── Toggle learned for a new curriculum word ────────────
  const toggleWordLearned = useCallback((w: HSK1Word) => {
    const oldWord = vocabulary.find(v => v.zh === w.chinese)
    if (oldWord) {
      store.toggleLearned(oldWord.id)
      store.incrementStreak()
    }
  }, [store])

  const toggleWordBookmark = useCallback((w: HSK1Word) => {
    const oldWord = vocabulary.find(v => v.zh === w.chinese)
    if (oldWord) {
      store.toggleBookmark(oldWord.id)
    }
  }, [store])

  // ─── Get old vocabulary word for matching ────────────────
  const getOldWord = useCallback((w: HSK1Word): VocabWord | undefined => {
    return vocabulary.find(v => v.zh === w.chinese)
  }, [])

  // ─── View mode tabs ──────────────────────────────────────
  const viewTabs = [
    { key: 'grid' as const, label: 'البطاقات', icon: Grid3X3 },
    { key: 'flashcards' as const, label: 'عرض', icon: Layers },
    { key: 'quizlet' as const, label: '🎯 كويزلت', icon: Zap },
    { key: 'favorites' as const, label: `⭐ المفضلة (${bookmarkedWords.length})`, icon: BookmarkPlus },
    { key: 'list' as const, label: 'القائمة', icon: List },
  ]

  return (
    <div className="space-y-4" dir="rtl">
      {/* ─── Header & Stats ─────────────────────────────── */}
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h2 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-red-600 flex-shrink-0" />
            <span>المفردات</span>
          </h2>
          <div className="h-1 w-20 bg-gradient-to-r from-red-500 to-amber-500 rounded-full mt-2" />
          <p className="text-sm text-gray-500 mt-1">
            {selectedLesson > 0
              ? `الدرس ${selectedLesson}: ${hsk1Lessons.find(l => l.num === selectedLesson)?.titleAr}`
              : 'جميع الدروس — HSK 1'}
          </p>
        </div>
        <div className="flex flex-col items-end gap-1 flex-shrink-0">
          <Badge variant="secondary" className="text-xs">{filteredWords.length} كلمة</Badge>
          <div className="flex items-center gap-1.5 text-xs">
            <span className="flex items-center gap-0.5 text-emerald-600"><Check className="w-3 h-3" />{stats.mastered}</span>
            <span className="text-gray-300">|</span>
            <span className="flex items-center gap-0.5 text-amber-600"><Star className="w-3 h-3" />{stats.learning}</span>
            <span className="text-gray-300">|</span>
            <span className="flex items-center gap-0.5 text-gray-400"><Sparkles className="w-3 h-3" />{stats.newCount}</span>
          </div>
        </div>
      </div>

      {/* ─── Progress bar ───────────────────────────────── */}
      <div className="space-y-1">
        <div className="flex justify-between items-center text-xs">
          <span className="text-gray-500">التقدم</span>
          <span className="font-bold text-gray-700">{stats.percent}%</span>
        </div>
        <Progress value={stats.percent} className="h-2" />
      </div>

      {/* ─── Search Bar ─────────────────────────────────── */}
      <div className="relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <Input
          placeholder="ابحث بالصينية أو البيني أو العربية..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pr-10 pl-10"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
          >
            ✕
          </button>
        )}
      </div>

      {/* ─── Lesson Selector Chips ──────────────────────── */}
      <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
        <button
          onClick={() => setSelectedLesson(0)}
          className={`flex-shrink-0 px-3 py-1.5 rounded-xl text-xs font-medium transition-all border ${
            selectedLesson === 0
              ? 'bg-red-600 text-white border-red-600 shadow-sm'
              : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-50'
          }`}
        >
          جميع الدروس ({hsk1AllWords.length})
        </button>
        {hsk1Lessons.map(lesson => {
          const lessonMastered = lesson.words.filter(w => getWordStatus(w, store.learnedWords, store.bookmarkedWords) === 'mastered').length
          return (
            <button
              key={lesson.num}
              onClick={() => setSelectedLesson(lesson.num)}
              className={`flex-shrink-0 px-3 py-1.5 rounded-xl text-xs font-medium transition-all border ${
                selectedLesson === lesson.num
                  ? 'bg-red-600 text-white border-red-600 shadow-sm'
                  : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-50'
              }`}
            >
              <span className="hidden sm:inline">{lesson.titleZh} — </span>
              <span>L{lesson.num}</span>
              <span className="text-[10px] opacity-70 mr-1">({lessonMastered}/{lesson.words.length})</span>
            </button>
          )
        })}
      </div>

      {/* ─── Category Chips ─────────────────────────────── */}
      <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
        {SEMANTIC_CATEGORIES.map(cat => (
          <button
            key={cat.value}
            onClick={() => setSelectedCategory(cat.value)}
            className={`flex-shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all border ${
              selectedCategory === cat.value
                ? 'bg-gray-900 text-white border-gray-900'
                : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-50'
            }`}
          >
            <cat.icon className="w-3 h-3" />
            {cat.label}
          </button>
        ))}
      </div>

      {/* ─── Toolbar: Sort + Toggles + View Tabs ──────── */}
      <div className="flex flex-col sm:flex-row gap-2 items-start sm:items-center justify-between">
        {/* Sort dropdown */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1">
            <ArrowUpDown className="w-3.5 h-3.5 text-gray-400" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as SortOption)}
              className="text-xs bg-white border border-gray-200 rounded-lg px-2 py-1.5 text-gray-700 focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-400"
            >
              {SORT_OPTIONS.map(opt => (
                <option key={opt.value} value={opt.value}>{opt.label}</option>
              ))}
            </select>
          </div>
          {/* Toggle chips */}
          <button
            onClick={() => setHideMastered(!hideMastered)}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors flex items-center gap-1 border ${
              hideMastered ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-white text-gray-500 border-gray-200'
            }`}
          >
            {hideMastered ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
            {hideMastered ? 'إظهار المحفوظة' : 'إخفاء المحفوظة'}
          </button>
          <button
            onClick={() => setHideNew(!hideNew)}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors flex items-center gap-1 border ${
              hideNew ? 'bg-blue-50 text-blue-700 border-blue-200' : 'bg-white text-gray-500 border-gray-200'
            }`}
          >
            <Sparkles className="w-3 h-3" />
            {hideNew ? 'إظهار الجديدة' : 'إخفاء الجديدة'}
          </button>
          <button
            onClick={() => setShowPinyin(!showPinyin)}
            className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors border ${
              showPinyin ? 'bg-red-50 text-red-700 border-red-200' : 'bg-white text-gray-500 border-gray-200'
            }`}
          >
            {showPinyin ? '🔑 إخفاء البيني' : '🔑 إظهار البيني'}
          </button>
        </div>
      </div>

      {/* ─── View Tabs ──────────────────────────────────── */}
      <div className="flex gap-1 bg-gray-100 p-1 rounded-xl">
        {viewTabs.map(tab => (
          <button
            key={tab.key}
            onClick={() => setViewMode(tab.key)}
            className={`flex-1 px-2 py-2 rounded-lg text-xs font-medium transition-all flex items-center justify-center gap-1 ${
              viewMode === tab.key
                ? 'bg-white text-red-700 shadow-sm'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            <tab.icon className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{tab.label}</span>
          </button>
        ))}
      </div>

      {/* ─── Grid View ──────────────────────────────────── */}
      {viewMode === 'grid' && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          <AnimatePresence mode="popLayout">
            {filteredWords.map((word) => {
              const status = getWordStatus(word, store.learnedWords, store.bookmarkedWords)
              const config = STATUS_CONFIG[status]
              const isExpanded = expandedCard === word.chinese
              const oldWord = getOldWord(word)

              return (
                <motion.div
                  key={word.chinese}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ duration: 0.2 }}
                >
                  <Card
                    className={`cursor-pointer transition-all duration-200 hover:shadow-md hover:-translate-y-0.5 border overflow-hidden ${
                      isExpanded ? 'ring-2 ring-red-400 shadow-md' : ''
                    } ${config.border}`}
                    onClick={() => setExpandedCard(isExpanded ? null : word.chinese)}
                  >
                    {/* Status indicator bar */}
                    <div className={`h-1 w-full ${status === 'mastered' ? 'bg-emerald-500' : status === 'learning' ? 'bg-amber-500' : 'bg-gray-200'}`} />

                    <CardContent className="p-3 sm:p-4 space-y-2">
                      {/* Top row: lesson badge + status */}
                      <div className="flex items-center justify-between">
                        <Badge variant="outline" className="text-[10px] font-mono px-1.5 py-0 bg-gray-50">
                          L{word.lesson}
                        </Badge>
                        <div className="flex items-center gap-1">
                          <button
                            onClick={(e) => { e.stopPropagation(); toggleWordBookmark(word) }}
                            className={`w-6 h-6 flex items-center justify-center rounded-full transition-colors ${
                              status === 'learning' ? 'text-amber-500' : 'text-gray-300 hover:text-amber-400'
                            }`}
                          >
                            <Star className="w-3.5 h-3.5" fill={status === 'learning' ? 'currentColor' : 'none'} />
                          </button>
                          <button
                            onClick={(e) => { e.stopPropagation(); speak(word.chinese) }}
                            className="w-6 h-6 flex items-center justify-center rounded-full text-gray-400 hover:text-red-500 transition-colors"
                          >
                            <Volume2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {/* Chinese character */}
                      <div
                        className="font-chinese-serif text-3xl sm:text-4xl text-gray-900 text-center py-2 leading-tight select-none"
                        onClick={(e) => { e.stopPropagation(); speak(word.chinese) }}
                      >
                        {word.chinese}
                      </div>

                      {/* Pinyin */}
                      {showPinyin && (
                        <p className="font-chinese-sans text-sm text-gray-500 text-center">
                          {word.pinyin}
                        </p>
                      )}

                      {/* Arabic meaning */}
                      <p className="text-sm font-medium text-gray-800 text-center leading-relaxed">
                        {word.arabic}
                      </p>

                      {/* Status badge */}
                      <div className="flex justify-center">
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium ${config.bg} ${config.color}`}>
                          <config.icon className="w-3 h-3" />
                          {config.label}
                        </span>
                      </div>

                      {/* Expanded section: example sentences from old vocab */}
                      <AnimatePresence>
                        {isExpanded && oldWord && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ duration: 0.2 }}
                            className="overflow-hidden"
                          >
                            <div className="pt-2 mt-2 border-t border-gray-100 space-y-2">
                              {/* Mnemonic */}
                              {oldWord.mnemonic && (
                                <div className="bg-blue-50 rounded-lg px-2.5 py-1.5">
                                  <p className="text-[10px] text-blue-600">💡 {oldWord.mnemonic}</p>
                                </div>
                              )}

                              {/* Example sentences */}
                              <div className="space-y-1.5">
                                <p className="text-[10px] font-medium text-gray-500">📝 أمثلة:</p>
                                {wordSentences(oldWord).slice(0, 2).map((s, i) => (
                                  <button
                                    key={i}
                                    onClick={(e) => { e.stopPropagation(); speak(s.zh) }}
                                    className="w-full text-right bg-gray-50 hover:bg-gray-100 rounded-lg px-2.5 py-1.5 transition-colors"
                                  >
                                    <p className="text-xs text-gray-800 font-chinese-sans">{s.zh}</p>
                                    <p className="text-[10px] text-gray-400 font-chinese-sans">{s.pinyin}</p>
                                    <p className="text-[10px] text-gray-500">{s.ar}</p>
                                  </button>
                                ))}
                              </div>

                              {/* Master toggle button */}
                              <button
                                onClick={(e) => {
                                  e.stopPropagation()
                                  toggleWordLearned(word)
                                }}
                                className={`w-full py-2 rounded-xl text-xs font-medium transition-colors ${
                                  status === 'mastered'
                                    ? 'bg-emerald-100 text-emerald-700 hover:bg-emerald-200'
                                    : 'bg-gray-100 text-gray-700 hover:bg-red-50 hover:text-red-700'
                                }`}
                              >
                                {status === 'mastered' ? '✓ تم الإتقان — انقر للتراجع' : '★ علامة كـ متقن'}
                              </button>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </CardContent>
                  </Card>
                </motion.div>
              )
            })}
          </AnimatePresence>
        </div>
      )}

      {/* ─── Empty State ────────────────────────────────── */}
      {viewMode === 'grid' && filteredWords.length === 0 && (
        <div className="flex flex-col items-center justify-center py-16 gap-4">
          <div className="w-20 h-20 rounded-full bg-gray-100 flex items-center justify-center">
            <Search className="w-8 h-8 text-gray-300" />
          </div>
          <div className="text-center">
            <p className="text-gray-500 font-medium">لا توجد نتائج</p>
            <p className="text-sm text-gray-400 mt-1">جرّب تغيير عوامل التصفية أو البحث بكلمات أخرى</p>
          </div>
          <Button variant="outline" size="sm" onClick={() => { setSearchQuery(''); setSelectedLesson(0); setSelectedCategory('all'); setHideMastered(false); setHideNew(false) }}>
            إعادة ضبط الفلاتر
          </Button>
        </div>
      )}

      {/* ─── Flashcard View (old vocabulary) ────────────── */}
      {viewMode === 'flashcards' && <FlashcardView filteredVocab={vocabulary} showPinyin={showPinyin} />}

      {/* ─── Quizlet View ───────────────────────────────── */}
      {viewMode === 'quizlet' && <QuizletFlashcard vocabulary={vocabulary} />}

      {/* ─── Favorites View ─────────────────────────────── */}
      {viewMode === 'favorites' && (
        <div className="space-y-3">
          {bookmarkedWords.length === 0 ? (
            <Card className="border-0 shadow-sm">
              <CardContent className="flex flex-col items-center justify-center py-12 gap-3">
                <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center">
                  <BookmarkPlus className="w-7 h-7 text-gray-400" />
                </div>
                <p className="text-sm text-gray-500 text-center">لا توجد كلمات في المفضلة بعد<br />اضغط على نجمة ⭐ لحفظ كلمة</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
              {bookmarkedWords.map(word => {
                const status = getWordStatus(word, store.learnedWords, store.bookmarkedWords)
                const config = STATUS_CONFIG[status]
                return (
                  <motion.div
                    key={word.chinese}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.15 }}
                  >
                    <Card className={`border ${config.border} hover:shadow-md transition-shadow`}>
                      <div className={`h-1 ${status === 'mastered' ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                      <CardContent className="p-3 text-center space-y-1.5">
                        <div className="flex justify-between items-center">
                          <Badge variant="outline" className="text-[10px] px-1.5 py-0 bg-gray-50">L{word.lesson}</Badge>
                          <button onClick={() => speak(word.chinese)} className="text-gray-400 hover:text-red-500">
                            <Volume2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <div className="font-chinese-serif text-3xl text-gray-900 py-1">{word.chinese}</div>
                        {showPinyin && <p className="font-chinese-sans text-xs text-gray-500">{word.pinyin}</p>}
                        <p className="text-sm text-gray-800">{word.arabic}</p>
                        <button
                          onClick={() => toggleWordBookmark(word)}
                          className="text-amber-500 hover:text-amber-600"
                        >
                          <Star className="w-4 h-4 fill-current mx-auto" />
                        </button>
                      </CardContent>
                    </Card>
                  </motion.div>
                )
              })}
            </div>
          )}
        </div>
      )}

      {/* ─── List View ──────────────────────────────────── */}
      {viewMode === 'list' && (
        <Card className="border-0 shadow-sm">
          <ScrollArea className="max-h-[500px]">
            <div className="space-y-1 p-2">
              {filteredWords.map((w) => {
                const status = getWordStatus(w, store.learnedWords, store.bookmarkedWords)
                const config = STATUS_CONFIG[status]
                const oldWord = getOldWord(w)
                return (
                  <motion.button
                    key={w.chinese}
                    initial={{ opacity: 0, x: 10 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-right transition-colors hover:bg-gray-50 border border-transparent hover:border-gray-100"
                    onClick={() => { speak(w.chinese) }}
                  >
                    {/* Status dot */}
                    <div className={`w-2 h-2 rounded-full flex-shrink-0 ${status === 'mastered' ? 'bg-emerald-500' : status === 'learning' ? 'bg-amber-500' : 'bg-gray-300'}`} />

                    {/* Chinese */}
                    <span className="font-chinese-serif text-lg w-16 text-gray-900">{w.chinese}</span>

                    {/* Pinyin */}
                    {showPinyin && (
                      <span className="text-xs text-gray-500 font-chinese-sans w-28 flex-shrink-0">{w.pinyin}</span>
                    )}

                    {/* Arabic */}
                    <span className="text-sm text-gray-700 flex-1 truncate">{w.arabic}</span>

                    {/* Lesson badge */}
                    <Badge variant="outline" className="text-[10px] px-1.5 py-0 bg-gray-50 flex-shrink-0">L{w.lesson}</Badge>

                    {/* Actions */}
                    <div className="flex items-center gap-1 flex-shrink-0">
                      {status === 'learning' && <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />}
                      {status === 'mastered' && <Check className="w-4 h-4 text-emerald-600" />}
                    </div>
                  </motion.button>
                )
              })}
            </div>
          </ScrollArea>
        </Card>
      )}

      {/* ─── Results count (bottom) ─────────────────────── */}
      {filteredWords.length > 0 && viewMode === 'grid' && (
        <div className="text-center text-xs text-gray-400 pt-2">
          عرض {filteredWords.length} كلمة من أصل {stats.total}
        </div>
      )}
    </div>
  )
}

// ─── Helper: Build sentence list for old vocab word ──────
function wordSentences(word: VocabWord): { zh: string; pinyin: string; ar: string }[] {
  const sents: { zh: string; pinyin: string; ar: string }[] = [
    { zh: word.exZh, pinyin: word.exPinyin, ar: word.exEn },
  ]
  if (word.s2) sents.push({ zh: word.s2.zh, pinyin: word.s2.py, ar: word.s2.ar })
  if (word.s3) sents.push({ zh: word.s3.zh, pinyin: word.s3.py, ar: word.s3.ar })
  return sents.filter(s => s.zh)
}

// ─── Sub-component: Flashcard View ───────────────────────
function FlashcardView({ filteredVocab, showPinyin }: { filteredVocab: VocabWord[]; showPinyin: boolean }) {
  const store = useLearningStore()
  const word = filteredVocab[store.flashcardIndex]
  const sentences = useMemo(() => (word ? wordSentences(word) : []), [word])

  if (!word) return null

  return (
    <div className="space-y-4">
      <div className="perspective-1000 w-full">
        <div
          className={`relative w-full min-h-[260px] sm:min-h-[300px] cursor-pointer transition-transform duration-500 preserve-3d ${store.isFlipped ? 'rotate-y-180' : ''}`}
          onClick={() => store.flip()}
        >
          {/* Front */}
          <div className="absolute inset-0 backface-hidden bg-gradient-to-br from-white via-red-50/30 to-white rounded-2xl flashcard-enhanced flex flex-col items-center justify-center p-6 gap-4">
            <div className="absolute top-3 right-3 flex gap-1">
              <Badge variant="outline" className="text-xs font-chinese-sans bg-white/80">{word.pos}</Badge>
              {word.lesson && <Badge variant="outline" className="text-xs bg-white/80">L{word.lesson}</Badge>}
            </div>
            <div className="font-chinese-serif text-6xl sm:text-7xl text-gray-900 mb-1 drop-shadow-sm" onClick={(e) => { e.stopPropagation(); speak(word.zh) }}>
              {word.zh}
            </div>
            <div className="font-chinese-sans text-xl text-gray-500" onClick={(e) => { e.stopPropagation(); speak(word.pinyin) }}>
              {showPinyin && word.pinyin}
            </div>
            <p className="text-sm text-gray-400 mt-1">اضغط للنطق • مسافة أو انقر للقلب</p>
          </div>

          {/* Back */}
          <div className="absolute inset-0 backface-hidden rotate-y-180 bg-gradient-to-br from-white via-amber-50/30 to-white rounded-2xl flashcard-enhanced flex flex-col items-center justify-center p-5 overflow-y-auto custom-scrollbar">
            <div className="text-center mb-3">
              <div className="font-chinese-serif text-4xl font-bold text-gray-900 mb-1">{word.zh}</div>
              <div className="font-chinese-sans text-base text-gray-500">{word.pinyin}</div>
              <div className="text-lg font-bold text-red-600 mt-1">{word.meaning}</div>
            </div>
            {word.mnemonic && (
              <div className="bg-blue-50 rounded-lg px-3 py-2 mb-3 text-center">
                <span className="text-xs font-medium text-blue-600">💡 {word.mnemonic}</span>
              </div>
            )}
            <div className="w-full space-y-2">
              <div className="text-xs font-medium text-gray-500 text-center">📝 أمثلة:</div>
              {sentences.slice(0, 3).map((s, i) => (
                <button key={i} onClick={(e) => { e.stopPropagation(); speak(s.zh) }}
                  className="w-full text-right bg-white/60 hover:bg-white rounded-lg px-3 py-2 transition-colors group">
                  <div className="font-chinese-sans text-sm text-gray-800 group-hover:text-red-600 transition-colors">{s.zh}</div>
                  <div className="font-chinese-sans text-xs text-gray-400">{s.pinyin}</div>
                  <div className="text-xs text-gray-500">{s.ar}</div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between max-w-lg mx-auto">
        <Button
          variant="outline"
          size="sm"
          onClick={() => store.setFlashcardIndex(store.flashcardIndex - 1)}
          disabled={store.flashcardIndex === 0}
        >
          <ChevronRight className="w-4 h-4" />
          السابق
        </Button>
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant={store.isLearned(word.id) ? 'default' : 'outline'}
            onClick={() => { store.toggleLearned(word.id); store.incrementStreak() }}
            className={store.isLearned(word.id) ? 'bg-emerald-600 hover:bg-emerald-700' : ''}
          >
            {store.isLearned(word.id) ? <><Check className="w-4 h-4 ml-1" /> تم الحفظ</> : <><Star className="w-4 h-4 ml-1" /> حفظ</>}
          </Button>
          <Button
            size="sm"
            variant={store.isBookmarked(word.id) ? 'default' : 'ghost'}
            onClick={() => store.toggleBookmark(word.id)}
            className={store.isBookmarked(word.id) ? 'bg-amber-500 hover:bg-amber-600' : 'text-gray-400 hover:text-amber-500'}
          >
            <BookmarkPlus className="w-4 h-4" />
          </Button>
          <Button size="sm" variant="ghost" onClick={() => speak(word.zh)}>
            <Volume2 className="w-4 h-4" />
          </Button>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => store.setFlashcardIndex(store.flashcardIndex + 1)}
          disabled={store.flashcardIndex >= filteredVocab.length - 1}
        >
          التالي
          <ChevronLeft className="w-4 h-4" />
        </Button>
      </div>

      <div className="text-center text-sm text-gray-500">
        {store.flashcardIndex + 1} / {filteredVocab.length}
      </div>

      {/* Radicals */}
      {word.radicals && word.radicals.length > 0 && (
        <Card className="border-0 shadow-sm bg-gradient-to-l from-purple-50 to-indigo-50/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-3">
              <Zap className="w-4 h-4 text-purple-500" />
              <span className="text-sm font-medium text-gray-700">تحليل الحروف والجذور</span>
            </div>
            <div className="flex gap-3 justify-center flex-wrap">
              {word.zh.split('').map((char, i) => {
                const vocabMatch = vocabulary.find(v => v.zh === char)
                return (
                  <div key={i} className="text-center group">
                    <button
                      onClick={() => speak(char)}
                      className="w-16 h-16 rounded-xl bg-gradient-to-br from-purple-50 to-indigo-50 border-2 border-purple-100 flex items-center justify-center mb-1 group-hover:shadow-md group-hover:border-purple-300 transition-all cursor-pointer"
                    >
                      <span className="font-chinese-serif text-3xl text-purple-800">{char}</span>
                    </button>
                    {vocabMatch && <div className="text-[10px] text-gray-500">{vocabMatch.meaning}</div>}
                    {word.radicals[i] && word.radicals[i] !== char && <div className="text-[9px] text-purple-400 mt-0.5">Radical: {word.radicals[i]}</div>}
                    {word.strokeCount && i === 0 && <div className="text-[9px] text-gray-400 mt-0.5">{word.strokeCount} strokes</div>}
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
