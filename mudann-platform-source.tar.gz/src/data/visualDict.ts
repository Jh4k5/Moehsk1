// ─── Visual Dictionary ────────────────────────────────────────────────────────
// Phase 3 – Emoji-annotated vocabulary organised by semantic category
// 117 words across 14 categories

export interface VisualDictWord {
  hanzi: string
  pinyin: string
  arabic: string
  emoji: string
  example?: string
  exampleAr?: string
}

export interface VisualDictCategory {
  key: string
  label: string
  icon: string
  words: VisualDictWord[]
}

export const VISUAL_DICT_CATEGORIES: VisualDictCategory[] = [
  // ════════════════════════════════════════════════════════════════════════════
  // 🔢 الأرقام – Numbers (14)
  // ════════════════════════════════════════════════════════════════════════════
  {
    key: "numbers",
    label: "الأرقام",
    icon: "🔢",
    words: [
      { hanzi: "零", pinyin: "líng", arabic: "صفر", emoji: "0️⃣", example: "零是一个数字。", exampleAr: "الصفر هو رقم." },
      { hanzi: "一", pinyin: "yī", arabic: "واحد", emoji: "1️⃣", example: "我有一个苹果。", exampleAr: "لدي تفاحة واحدة." },
      { hanzi: "二", pinyin: "èr", arabic: "اثنان", emoji: "2️⃣", example: "我家有两个人。", exampleAr: "عائلتي من شخصين." },
      { hanzi: "三", pinyin: "sān", arabic: "ثلاثة", emoji: "3️⃣", example: "我买了三本书。", exampleAr: "اشتريت ثلاثة كتب." },
      { hanzi: "四", pinyin: "sì", arabic: "أربعة", emoji: "4️⃣", example: "现在四点了。", exampleAr: "الآن الساعة الرابعة." },
      { hanzi: "五", pinyin: "wǔ", arabic: "خمسة", emoji: "5️⃣", example: "我家有五口人。", exampleAr: "عائلتي من خمسة أشخاص." },
      { hanzi: "六", pinyin: "liù", arabic: "ستة", emoji: "6️⃣", example: "今天是星期六。", exampleAr: "اليوم هو السبت." },
      { hanzi: "七", pinyin: "qī", arabic: "سبعة", emoji: "7️⃣", example: "今天是七月七号。", exampleAr: "اليوم هو السابع من يوليو." },
      { hanzi: "八", pinyin: "bā", arabic: "ثمانية", emoji: "8️⃣", example: "八点上课。", exampleAr: "الدرس يبدأ في الثامنة." },
      { hanzi: "九", pinyin: "jiǔ", arabic: "تسعة", emoji: "9️⃣", example: "他今年九岁。", exampleAr: "هو يبلغ من العمر تسع سنوات." },
      { hanzi: "十", pinyin: "shí", arabic: "عشرة", emoji: "🔟", example: "十是双数。", exampleAr: "عشرة عدد زوجي." },
      { hanzi: "二十", pinyin: "èrshí", arabic: "عشرون", emoji: "20️⃣", example: "这件衣服二十块。", exampleAr: "هذا الثوب سعره عشرون يوان." },
      { hanzi: "五十", pinyin: "wǔshí", arabic: "خمسون", emoji: "50️⃣", example: "五十块钱够吗？", exampleAr: "هل خمسون يوان تكفي؟" },
      { hanzi: "百", pinyin: "bǎi", arabic: "مئة", emoji: "💯", example: "一百块太贵了。", exampleAr: "مئة يوان غالية جداً." },
    ],
  },

  // ════════════════════════════════════════════════════════════════════════════
  // 🍜 الطعام – Food (16)
  // ════════════════════════════════════════════════════════════════════════════
  {
    key: "food",
    label: "الطعام",
    icon: "🍜",
    words: [
      { hanzi: "米饭", pinyin: "mǐfàn", arabic: "أرز", emoji: "🍚", example: "我想吃米饭。", exampleAr: "أريد أن آكل الأرز." },
      { hanzi: "面条", pinyin: "miàntiáo", arabic: "معكرونة / نودلز", emoji: "🍜", example: "中国的面条很好吃。", exampleAr: "النودلز الصينية لذيذة جداً." },
      { hanzi: "饺子", pinyin: "jiǎozi", arabic: "زلابية", emoji: "🥟", example: "你会做饺子吗？", exampleAr: "هل يمكنك صنع الزلابية؟" },
      { hanzi: "包子", pinyin: "bāozi", arabic: "كعك محشي على البخار", emoji: "🥖", example: "早餐我吃包子。", exampleAr: "أكل كعك البخار على الإفطار." },
      { hanzi: "苹果", pinyin: "píngguǒ", arabic: "تفاح", emoji: "🍎", example: "我喜欢吃苹果。", exampleAr: "أحب أكل التفاح." },
      { hanzi: "香蕉", pinyin: "xiāngjiāo", arabic: "موز", emoji: "🍌", example: "香蕉是黄色的。", exampleAr: "الموز أصفر." },
      { hanzi: "茶", pinyin: "chá", arabic: "شاي", emoji: "🍵", example: "请给我一杯茶。", exampleAr: "من فضلك أعطني كوب شاي." },
      { hanzi: "水", pinyin: "shuǐ", arabic: "ماء", emoji: "💧", example: "我想喝一杯水。", exampleAr: "أريد أن أشرب كوب ماء." },
      { hanzi: "牛奶", pinyin: "niúnǎi", arabic: "حليب", emoji: "🥛", example: "早饭我喝牛奶。", exampleAr: "أشرب الحليب على الإفطار." },
      { hanzi: "鸡蛋", pinyin: "jīdàn", arabic: "بيضة", emoji: "🥚", example: "我要一个鸡蛋。", exampleAr: "أريد بيضة واحدة." },
      { hanzi: "菜", pinyin: "cài", arabic: "خضار / طبق", emoji: "🥬", example: "这个菜很好吃。", exampleAr: "هذا الطبق لذيذ." },
      { hanzi: "面包", pinyin: "miànbāo", arabic: "خبز", emoji: "🍞", example: "面包在桌子上。", exampleAr: "الخبز على الطاولة." },
      { hanzi: "水果", pinyin: "shuǐguǒ", arabic: "فواكه", emoji: "🍇", example: "我喜欢吃水果。", exampleAr: "أحب أكل الفواكه." },
      { hanzi: "晚饭", pinyin: "wǎnfàn", arabic: "عشاء", emoji: "🍽️", example: "我们晚上一起吃晚饭吧。", exampleAr: "نتناول العشاء معاً مساءً." },
      { hanzi: "午饭", pinyin: "wǔfàn", arabic: "غداء", emoji: "🍱", example: "中午你想吃什么午饭？", exampleAr: "ماذا تريد أن تأكل على الغداء؟" },
      { hanzi: "早饭", pinyin: "zǎofàn", arabic: "إفطار", emoji: "🍳", example: "早饭你吃面包和鸡蛋。", exampleAr: "تأكل خبز وبيض على الإفطار." },
    ],
  },

  // ════════════════════════════════════════════════════════════════════════════
  // 👨‍👩‍👧 العائلة – Family (9)
  // ════════════════════════════════════════════════════════════════════════════
  {
    key: "family",
    label: "العائلة",
    icon: "👨‍👩‍👧",
    words: [
      { hanzi: "爸爸", pinyin: "bàba", arabic: "أب / بابا", emoji: "👨", example: "我爸爸在医院工作。", exampleAr: "أبي يعمل في المستشفى." },
      { hanzi: "妈妈", pinyin: "māma", arabic: "أم / ماما", emoji: "👩", example: "我妈妈做晚饭很好吃。", exampleAr: "عشاء والدتي لذيذ جداً." },
      { hanzi: "哥哥", pinyin: "gēge", arabic: "أخ أكبر", emoji: "👦", example: "我哥哥在大学学习。", exampleAr: "أخي الأكبر يدرس في الجامعة." },
      { hanzi: "姐姐", pinyin: "jiějie", arabic: "أخت أكبر", emoji: "👧", example: "我姐姐喜欢唱歌。", exampleAr: "أختي الكبرى تحب الغناء." },
      { hanzi: "弟弟", pinyin: "dìdi", arabic: "أخ أصغر", emoji: "🧒", example: "我弟弟今年五岁。", exampleAr: "أخي الأصغر يبلغ من العمر خمس سنوات." },
      { hanzi: "妹妹", pinyin: "mèimei", arabic: "أخت أصغر", emoji: "👶", example: "我妹妹是学生。", exampleAr: "أختي الصغرى طالبة." },
      { hanzi: "儿子", pinyin: "érzi", arabic: "ابن", emoji: "👦", example: "他有一个儿子。", exampleAr: "لديه ابن واحد." },
      { hanzi: "女儿", pinyin: "nǚ'ér", arabic: "ابنة", emoji: "👧", example: "她的女儿很漂亮。", exampleAr: "ابنتها جميلة جداً." },
      { hanzi: "朋友", pinyin: "péngyou", arabic: "صديق / صديقة", emoji: "👫", example: "他是我的好朋友。", exampleAr: "هو صديقي الجيد." },
    ],
  },

  // ════════════════════════════════════════════════════════════════════════════
  // 📍 الأماكن – Places (13)
  // ════════════════════════════════════════════════════════════════════════════
  {
    key: "places",
    label: "الأماكن",
    icon: "📍",
    words: [
      { hanzi: "学校", pinyin: "xuéxiào", arabic: "مدرسة", emoji: "🏫", example: "我在学校学习中文。", exampleAr: "أدرس اللغة الصينية في المدرسة." },
      { hanzi: "医院", pinyin: "yīyuàn", arabic: "مستشفى", emoji: "🏥", example: "他生病了，去医院看病。", exampleAr: "هو مريض، ذهب إلى المستشفى." },
      { hanzi: "超市", pinyin: "chāoshì", arabic: "سوبرماركت", emoji: "🏪", example: "我想去超市买东西。", exampleAr: "أريد أن أذهب إلى السوبرماركت للشراء." },
      { hanzi: "图书馆", pinyin: "túshūguǎn", arabic: "مكتبة", emoji: "📚", example: "我在图书馆看书。", exampleAr: "أقرأ كتباً في المكتبة." },
      { hanzi: "饭店", pinyin: "fàndiàn", arabic: "مطعم / فندق", emoji: "🍽️", example: "我们去饭店吃饭吧。", exampleAr: "لنذهب إلى المطعم لتناول الطعام." },
      { hanzi: "机场", pinyin: "jīchǎng", arabic: "مطار", emoji: "✈️", example: "飞机在机场等我们。", exampleAr: "الطائرة تنتظرنا في المطار." },
      { hanzi: "家", pinyin: "jiā", arabic: "منزل / بيت", emoji: "🏠", example: "我家在北京。", exampleAr: "منزلي في بكين." },
      { hanzi: "公司", pinyin: "gōngsī", arabic: "شركة", emoji: "🏢", example: "我每天去公司上班。", exampleAr: "أذهب إلى الشركة للعمل كل يوم." },
      { hanzi: "电影院", pinyin: "diànyǐngyuàn", arabic: "سينما", emoji: "🎬", example: "我们明天去看电影吧。", exampleAr: "لنذهب إلى السينما غداً." },
      { hanzi: "房间", pinyin: "fángjiān", arabic: "غرفة", emoji: "🚪", example: "我的房间很大。", exampleAr: "غرفتي كبيرة." },
      { hanzi: "大学", pinyin: "dàxué", arabic: "جامعة", emoji: "🎓", example: "他是北京大学的学生。", exampleAr: "هو طالب في جامعة بكين." },
      { hanzi: "商店", pinyin: "shāngdiàn", arabic: "متجر", emoji: "🏪", example: "这个商店的衣服很便宜。", exampleAr: "ملابس هذا المتجر رخيصة." },
      { hanzi: "书店", pinyin: "shūdiàn", arabic: "مكتبة (متجر كتب)", emoji: "📖", example: "我在书店买了一本书。", exampleAr: "اشتريت كتاباً من متجر الكتب." },
    ],
  },

  // ════════════════════════════════════════════════════════════════════════════
  // 🚆 المواصلات – Transport (4)
  // ════════════════════════════════════════════════════════════════════════════
  {
    key: "transport",
    label: "المواصلات",
    icon: "🚆",
    words: [
      { hanzi: "飞机", pinyin: "fēijī", arabic: "طائرة", emoji: "✈️", example: "他坐飞机去北京。", exampleAr: "سافر بالطائرة إلى بكين." },
      { hanzi: "火车", pinyin: "huǒchē", arabic: "قطار", emoji: "🚂", example: "我们坐火车去上海。", exampleAr: "نسافر بالقطار إلى شنغهاي." },
      { hanzi: "出租车", pinyin: "chūzūchē", arabic: "تاكسي", emoji: "🚕", example: "现在太晚了，我们坐出租车吧。", exampleAr: "الوقت متأخر، لنأخذ التاكسي." },
      { hanzi: "车", pinyin: "chē", arabic: "سيارة / مركبة", emoji: "🚗", example: "他会开车。", exampleAr: "هو يستطيع قيادة السيارة." },
    ],
  },

  // ════════════════════════════════════════════════════════════════════════════
  // 🌤 الطقس – Weather (7)
  // ════════════════════════════════════════════════════════════════════════════
  {
    key: "weather",
    label: "الطقس",
    icon: "🌤",
    words: [
      { hanzi: "下雨", pinyin: "xiàyǔ", arabic: "تمطر", emoji: "🌧️", example: "今天下雨了，别忘了带伞。", exampleAr: "إنها تمطر اليوم، لا تنسَ المظلة." },
      { hanzi: "下雪", pinyin: "xiàxuě", arabic: "يتساقط الثلج", emoji: "❄️", example: "冬天北京下雪了。", exampleAr: "يتساقط الثلج في بكين شتاءً." },
      { hanzi: "热", pinyin: "rè", arabic: "حار", emoji: "🌡️", example: "今天太热了。", exampleAr: "الجو حار جداً اليوم." },
      { hanzi: "冷", pinyin: "lěng", arabic: "بارد", emoji: "🥶", example: "今天有点儿冷。", exampleAr: "الجو بارد قليلاً اليوم." },
      { hanzi: "天气", pinyin: "tiānqì", arabic: "طقس", emoji: "⛅", example: "今天天气怎么样？", exampleAr: "كيف حال الطقس اليوم؟" },
      { hanzi: "雨", pinyin: "yǔ", arabic: "مطر", emoji: "🌧️", example: "外面在下雨。", exampleAr: "إنها تمطر بالخارج." },
      { hanzi: "雪", pinyin: "xuě", arabic: "ثلج", emoji: "❄️", example: "孩子们喜欢玩雪。", exampleAr: "الأطفال يحبون اللعب بالثلج." },
    ],
  },

  // ════════════════════════════════════════════════════════════════════════════
  // 😊 المشاعر – Emotions (8)
  // ════════════════════════════════════════════════════════════════════════════
  {
    key: "emotions",
    label: "المشاعر",
    icon: "😊",
    words: [
      { hanzi: "高兴", pinyin: "gāoxìng", arabic: "سعيد / مسرور", emoji: "😊", example: "认识你很高兴！", exampleAr: "سعيد بلقائك!" },
      { hanzi: "忙", pinyin: "máng", arabic: "مشغول", emoji: "🏃", example: "我今天很忙。", exampleAr: "أنا مشغول جداً اليوم." },
      { hanzi: "累", pinyin: "lèi", arabic: "متعب", emoji: "😮‍💨", example: "工作了一天，我很累。", exampleAr: "بعد يوم من العمل، أنا متعب." },
      { hanzi: "好", pinyin: "hǎo", arabic: "جيد / حسنًا", emoji: "👍", example: "这本书很好。", exampleAr: "هذا الكتاب جيد جداً." },
      { hanzi: "病", pinyin: "bìng", arabic: "مريض", emoji: "🤒", example: "他病了，不能来上课。", exampleAr: "هو مريض ولا يستطيع الحضور للدرس." },
      { hanzi: "漂亮", pinyin: "piàoliang", arabic: "جميل", emoji: "✨", example: "你的衣服很漂亮。", exampleAr: "ملابسك جميلة جداً." },
      { hanzi: "好吃", pinyin: "hǎochī", arabic: "لذيذ", emoji: "😋", example: "妈妈做的饭真好吃！", exampleAr: "طعام والدتي لذيذ حقاً!" },
      { hanzi: "好看", pinyin: "hǎokàn", arabic: "جميل (منظر)", emoji: "😍", example: "这个电脑真好看。", exampleAr: "هذا الكمبيوتر جميل المنظر." },
    ],
  },

  // ════════════════════════════════════════════════════════════════════════════
  // ⏰ الوقت – Time (11)
  // ════════════════════════════════════════════════════════════════════════════
  {
    key: "time",
    label: "الوقت",
    icon: "⏰",
    words: [
      { hanzi: "今天", pinyin: "jīntiān", arabic: "اليوم", emoji: "📅", example: "今天是我的生日。", exampleAr: "اليوم هو عيد ميلادي." },
      { hanzi: "明天", pinyin: "míngtiān", arabic: "غداً", emoji: "🔜", example: "明天我有课。", exampleAr: "لدي درس غداً." },
      { hanzi: "昨天", pinyin: "zuótiān", arabic: "أمس / البارحة", emoji: "🔙", example: "昨天我去了学校。", exampleAr: "ذهبت إلى المدرسة أمس." },
      { hanzi: "早上", pinyin: "zǎoshang", arabic: "صباحاً", emoji: "🌅", example: "早上我六点起床。", exampleAr: "أستيقظ الساعة صباحاً." },
      { hanzi: "晚上", pinyin: "wǎnshang", arabic: "مساءً", emoji: "🌙", example: "晚上我们在家看电视。", exampleAr: "نحن نشاهد التلفاز مساءً في المنزل." },
      { hanzi: "现在", pinyin: "xiànzài", arabic: "الآن", emoji: "⏱️", example: "现在几点了？", exampleAr: "كم الساعة الآن؟" },
      { hanzi: "中午", pinyin: "zhōngwǔ", arabic: "ظهيرة", emoji: "☀️", example: "中午十二点吃午饭。", exampleAr: "نتناول الغداء الساعة الثانية عشرة ظهراً." },
      { hanzi: "上午", pinyin: "shàngwǔ", arabic: "قبل الظهر", emoji: "🌤️", example: "上午我有三节课。", exampleAr: "لدي ثلاث حصص قبل الظهر." },
      { hanzi: "下午", pinyin: "xiàwǔ", arabic: "بعد الظهر", emoji: "🌆", example: "下午我去图书馆。", exampleAr: "أذهب إلى المكتبة بعد الظهر." },
      { hanzi: "小时", pinyin: "xiǎoshí", arabic: "ساعة", emoji: "⏰", example: "我每天学习两个小时。", exampleAr: "أدرس ساعتين كل يوم." },
      { hanzi: "年", pinyin: "nián", arabic: "سنة / عام", emoji: "🗓️", example: "今年是2024年。", exampleAr: "هذا العام هو 2024." },
    ],
  },

  // ════════════════════════════════════════════════════════════════════════════
  // 🦶 أجزاء الجسم – Body Parts (8)  ★ NEW
  // ════════════════════════════════════════════════════════════════════════════
  {
    key: "body",
    label: "أجزاء الجسم",
    icon: "🦶",
    words: [
      { hanzi: "手", pinyin: "shǒu", arabic: "يد", emoji: "🤚", example: "我的手很大。", exampleAr: "يدي كبيرة." },
      { hanzi: "眼", pinyin: "yǎn", arabic: "عين", emoji: "👁️", example: "她有一双大眼睛。", exampleAr: "لديها عينان كبيرتان." },
      { hanzi: "头", pinyin: "tóu", arabic: "رأس", emoji: "🗣️", example: "我的头有点儿疼。", exampleAr: "رأسي يؤلمني قليلاً." },
      { hanzi: "口", pinyin: "kǒu", arabic: "فم", emoji: "👄", example: "请张开嘴。", exampleAr: "من فضلك افتح فمك." },
      { hanzi: "耳", pinyin: "ěr", arabic: "أذن", emoji: "👂", example: "我的耳朵听不清楚。", exampleAr: "أذني لا تسمع بوضوح." },
      { hanzi: "鼻", pinyin: "bí", arabic: "أنف", emoji: "👃", example: "他的鼻子很大。", exampleAr: "أنفه كبيرة." },
      { hanzi: "脚", pinyin: "jiǎo", arabic: "قدم", emoji: "🦶", example: "我走路走得脚疼。", exampleAr: "قدمي تؤلمني من المشي." },
      { hanzi: "心", pinyin: "xīn", arabic: "قلب", emoji: "❤️", example: "我喜欢你，真心地。", exampleAr: "أنا أحبك، بصدق." },
    ],
  },

  // ════════════════════════════════════════════════════════════════════════════
  // 🐾 الحيوانات – Animals (5)  ★ NEW
  // ════════════════════════════════════════════════════════════════════════════
  {
    key: "animals",
    label: "الحيوانات",
    icon: "🐾",
    words: [
      { hanzi: "猫", pinyin: "māo", arabic: "قطة", emoji: "🐱", example: "她家有一只小猫。", exampleAr: "لديها قطة صغيرة في المنزل." },
      { hanzi: "狗", pinyin: "gǒu", arabic: "كلب", emoji: "🐕", example: "他喜欢跟狗玩。", exampleAr: "هو يحب اللعب مع الكلب." },
      { hanzi: "鸟", pinyin: "niǎo", arabic: "طائر", emoji: "🐦", example: "树上有三只鸟。", exampleAr: "هناك ثلاثة طيور على الشجرة." },
      { hanzi: "鱼", pinyin: "yú", arabic: "سمكة", emoji: "🐟", example: "这条鱼真好吃。", exampleAr: "هذه السمكة لذيذة حقاً." },
      { hanzi: "马", pinyin: "mǎ", arabic: "حصان", emoji: "🐴", example: "他骑马去公园。", exampleAr: "يركب الحصان إلى الحديقة." },
    ],
  },

  // ════════════════════════════════════════════════════════════════════════════
  // 📦 الأشياء – Objects (13)  ★ NEW
  // ════════════════════════════════════════════════════════════════════════════
  {
    key: "objects",
    label: "الأشياء",
    icon: "📦",
    words: [
      { hanzi: "书", pinyin: "shū", arabic: "كتاب", emoji: "📕", example: "我在看一本中文书。", exampleAr: "أقرأ كتاباً صينياً." },
      { hanzi: "电脑", pinyin: "diànnǎo", arabic: "كمبيوتر", emoji: "💻", example: "我的电脑很新。", exampleAr: "كمبيوتري جديد جداً." },
      { hanzi: "手机", pinyin: "shǒujī", arabic: "هاتف خلوي", emoji: "📱", example: "你的手机号是多少？", exampleAr: "ما هو رقم هاتفك؟" },
      { hanzi: "桌子", pinyin: "zhuōzi", arabic: "طاولة", emoji: "🍽️", example: "书在桌子上。", exampleAr: "الكتاب على الطاولة." },
      { hanzi: "椅子", pinyin: "yǐzi", arabic: "كرسي", emoji: "🪑", example: "请坐在这把椅子上。", exampleAr: "من فضلك اجلس على هذا الكرسي." },
      { hanzi: "杯子", pinyin: "bēizi", arabic: "كوب", emoji: "☕", example: "请给我一杯水。", exampleAr: "من فضلك أعطني كوب ماء." },
      { hanzi: "电视", pinyin: "diànshì", arabic: "تلفاز", emoji: "📺", example: "我们晚上看电视。", exampleAr: "نشاهد التلفاز مساءً." },
      { hanzi: "钱", pinyin: "qián", arabic: "نقود / مال", emoji: "💰", example: "我没有带钱。", exampleAr: "لم أحضر نقوداً معي." },
      { hanzi: "药", pinyin: "yào", arabic: "دواء", emoji: "💊", example: "你吃药了吗？", exampleAr: "هل تناولت الدواء؟" },
      { hanzi: "电影", pinyin: "diànyǐng", arabic: "فيلم", emoji: "🎬", example: "这个电影真好看。", exampleAr: "هذا الفيلم جميل حقاً." },
      { hanzi: "电话", pinyin: "diànhuà", arabic: "هاتف", emoji: "☎️", example: "我给你打电话。", exampleAr: "سأتصل بك هاتفياً." },
      { hanzi: "字", pinyin: "zì", arabic: "حرف / كلمة", emoji: "🔤", example: "这个字怎么写？", exampleAr: "كيف تكتب هذا الحرف؟" },
      { hanzi: "歌", pinyin: "gē", arabic: "أغنية", emoji: "🎵", example: "这首歌真好听。", exampleAr: "هذه الأغنية جميلة جداً." },
    ],
  },

  // ════════════════════════════════════════════════════════════════════════════
  // 👥 المهن والأشخاص – People (5)  ★ NEW
  // ════════════════════════════════════════════════════════════════════════════
  {
    key: "people",
    label: "المهن والأشخاص",
    icon: "👥",
    words: [
      { hanzi: "老师", pinyin: "lǎoshī", arabic: "معلم", emoji: "👨‍🏫", example: "我们的老师很好。", exampleAr: "معلمنا رائع جداً." },
      { hanzi: "医生", pinyin: "yīshēng", arabic: "طبيب", emoji: "👨‍⚕️", example: "医生让你多休息。", exampleAr: "الطبيب ينصحك بالراحة." },
      { hanzi: "学生", pinyin: "xuéshēng", arabic: "طالب", emoji: "👨‍🎓", example: "我是一个中国学生。", exampleAr: "أنا طالب صيني." },
      { hanzi: "服务员", pinyin: "fúwùyuán", arabic: "نادل / خادم", emoji: "🧑‍🍳", example: "服务员，请给我菜单。", exampleAr: "النادل، من فضلك أعطني القائمة." },
      { hanzi: "孩子", pinyin: "háizi", arabic: "أطفال / طفل", emoji: "👶", example: "孩子们在公园玩。", exampleAr: "الأطفال يلعبون في الحديقة." },
    ],
  },

  // ════════════════════════════════════════════════════════════════════════════
  // 👔 الملابس – Clothing (4)  ★ NEW
  // ════════════════════════════════════════════════════════════════════════════
  {
    key: "clothing",
    label: "الملابس",
    icon: "👔",
    words: [
      { hanzi: "衣服", pinyin: "yīfu", arabic: "ملابس", emoji: "👔", example: "你的衣服真好看。", exampleAr: "ملابسك جميلة حقاً." },
      { hanzi: "鞋", pinyin: "xié", arabic: "حذاء", emoji: "👟", example: "我想买一双新鞋。", exampleAr: "أريد شراء حذاء جديد." },
      { hanzi: "帽子", pinyin: "màozi", arabic: "قبعة", emoji: "🎩", example: "今天很冷，戴帽子吧。", exampleAr: "الجو بارد اليوم، ارتدِ قبعة." },
      { hanzi: "裤子", pinyin: "kùzi", arabic: "بنطلون", emoji: "👖", example: "这条裤子太贵了。", exampleAr: "هذا البنطلون غالي جداً." },
    ],
  },

  // ════════════════════════════════════════════════════════════════════════════
  // 🎯 الأنشطة اليومية – Daily Activities (8)  ★ NEW
  // ════════════════════════════════════════════════════════════════════════════
  {
    key: "activities",
    label: "الأنشطة اليومية",
    icon: "🎯",
    words: [
      { hanzi: "吃", pinyin: "chī", arabic: "يأكل", emoji: "🍽️", example: "我们在饭店吃饭。", exampleAr: "نأكل في المطعم." },
      { hanzi: "喝", pinyin: "hē", arabic: "يشرب", emoji: "🥤", example: "你想喝什么？", exampleAr: "ماذا تريد أن تشرب؟" },
      { hanzi: "睡觉", pinyin: "shuìjiào", arabic: "ينام", emoji: "😴", example: "我每天晚上十一点睡觉。", exampleAr: "أنام الساعة الحادية عشرة مساءً كل يوم." },
      { hanzi: "买", pinyin: "mǎi", arabic: "يشتري", emoji: "🛒", example: "我想买一部新手机。", exampleAr: "أريد شراء هاتف جديد." },
      { hanzi: "唱", pinyin: "chàng", arabic: "يغني", emoji: "🎤", example: "她唱歌真好听。", exampleAr: "غناؤها جميل حقاً." },
      { hanzi: "读", pinyin: "dú", arabic: "يقرأ", emoji: "📖", example: "他每天读书一个小时。", exampleAr: "يقرأ لمدة ساعة كل يوم." },
      { hanzi: "写", pinyin: "xiě", arabic: "يكتب", emoji: "✍️", example: "我在写汉字。", exampleAr: "أنا أكتب الحروف الصينية." },
      { hanzi: "看", pinyin: "kàn", arabic: "يشاهد / يرى", emoji: "👀", example: "我在看电视。", exampleAr: "أنا أشاهد التلفاز." },
    ],
  },
]
