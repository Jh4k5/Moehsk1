import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Section } from '@/types';
import {
  type SRSCard,
  type Quality,
  createSRSCard,
  calculateNextReview,
  isDueForReview,
  getWeakWords as getWeakWordsUtil,
} from './srs';

// Re-export Section for convenience
export type { Section };

// ── Existing interfaces ───────────────────────────────────────────────────
interface QuizHistoryEntry {
  date: string;
  score: number;
  total: number;
  difficulty: string;
  type: string;
}

interface DailyActivity {
  wordsLearned: number;
  questionsAnswered: number;
  gamesPlayed: number;
}

interface QuizQuestion {
  wordId: number;
  question: string;
  questionPinyin?: string;
  options: string[];
  correctIndex: number;
}

interface MemoryCard {
  id: number;
  zh: string;
  ar: string;
  pinyin: string;
  matched: boolean;
  type: 'hanzi' | 'meaning';
}

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

// ── Sync payload (data synced to server) ──────────────────────────────────
export interface SyncPayload {
  learnedWords: number[];
  bookmarkedWords: number[];
  completedStories: number[];
  quizHistory: QuizHistoryEntry[];
  highScores: Record<string, number>;
  dailyStreak: number;
  lastStudyDate: string;
  srsCards: Record<string, SRSCard>;
  dailyActivity: Record<string, DailyActivity>;
}

// ── SRS State ─────────────────────────────────────────────────────────────
interface SRSState {
  srsCards: Record<number, SRSCard>;
  rateWord: (wordId: number, quality: Quality) => void;
  getSRSStats: () => { total: number; new: number; learning: number; review: number; mastered: number };
  getDueCardIds: () => number[];
  getWeakWordIds: (limit?: number) => number[];
  getCardDifficulty: (wordId: number) => string;
}

// ── Game State ────────────────────────────────────────────────────────────
interface GameState {
  gameTimer: number;
  setGameTimer: (t: number) => void;
  gameDifficulty: 'easy' | 'medium' | 'hard';
  setGameDifficulty: (d: 'easy' | 'medium' | 'hard') => void;
  gameScore: number;
  setGameScore: (s: number) => void;
  gameStreak: number;
  setGameStreak: (s: number) => void;
}

// ── Exam State ────────────────────────────────────────────────────────────
interface ExamState {
  examStarted: boolean;
  examType: 'listening' | 'reading' | 'full' | null;
  examAnswers: Record<number, number>;
  examScore: number;
  examTimeRemaining: number;
  setExamState: (state: Partial<ExamState>) => void;
  resetExam: () => void;
}

// ── Sync State ────────────────────────────────────────────────────────────
interface SyncState {
  isSyncing: boolean;
  lastSyncedAt: number | null;
  isLoggedIn: boolean;
  setIsLoggedIn: (v: boolean) => void;
  syncToServer: () => Promise<void>;
  syncFromServer: () => Promise<void>;
  triggerSync: () => void;
}

// ── Combined Store ────────────────────────────────────────────────────────
interface LearningStore
  extends SRSState,
    GameState,
    ExamState,
    SyncState {
  // Navigation
  currentSection: Section;
  setCurrentSection: (section: Section) => void;

  // Progress
  learnedWords: number[];
  toggleLearned: (id: number) => void;
  isLearned: (id: number) => boolean;

  // Bookmarks
  bookmarkedWords: number[];
  isBookmarked: (id: number) => boolean;
  toggleBookmark: (id: number) => void;

  // Stories
  completedStories: number[];
  isStoryCompleted: (index: number) => boolean;
  toggleStoryCompleted: (index: number) => void;

  // Quiz History & High Scores
  quizHistory: QuizHistoryEntry[];
  addQuizHistory: (entry: QuizHistoryEntry) => void;
  highScores: Record<string, number>;
  updateHighScore: (game: string, score: number) => void;

  // Daily Activity
  dailyActivity: Record<string, DailyActivity>;
  recordDailyActivity: (date: string, words: number, questions: number, games: number) => void;

  // Flashcard
  flashcardIndex: number;
  setFlashcardIndex: (index: number) => void;
  isFlipped: boolean;
  flip: () => void;

  // Quiz
  quizScore: number;
  quizTotal: number;
  currentQuizQuestion: number;
  quizQuestions: QuizQuestion[];
  startQuiz: (questions: QuizQuestion[]) => void;
  answerQuiz: (correct: boolean) => void;
  resetQuiz: () => void;
  nextQuizQuestion: () => void;

  // Memory Game
  memoryCards: MemoryCard[];
  memoryMoves: number;
  memoryPairs: number;
  memoryLevel: number;
  setMemoryLevel: (level: number) => void;
  startMemoryGame: (cards: MemoryCard[]) => void;
  flipMemoryCard: (id: number) => void;
  matchMemoryPair: (id1: number, id2: number) => void;
  incrementMemoryMoves: () => void;
  resetMemoryGame: () => void;

  // Chat
  chatMessages: ChatMessage[];
  addChatMessage: (msg: ChatMessage) => void;
  clearChatMessages: () => void;

  // Streak
  dailyStreak: number;
  lastStudyDate: string;
  incrementStreak: () => void;
}

export type { QuizQuestion, MemoryCard, ChatMessage, QuizHistoryEntry, DailyActivity };

// ── Debounce utility ──────────────────────────────────────────────────────
let syncTimer: ReturnType<typeof setTimeout> | null = null;

export const useLearningStore = create<LearningStore>()(
  persist(
    (set, get) => ({
      // ── Navigation ────────────────────────────────────────────────────
      currentSection: 'dashboard' as Section,
      setCurrentSection: (section) => set({ currentSection: section }),

      // ── Progress ──────────────────────────────────────────────────────
      learnedWords: [],
      toggleLearned: (id) => {
        set((state) => ({
          learnedWords: state.learnedWords.includes(id)
            ? state.learnedWords.filter((w) => w !== id)
            : [...state.learnedWords, id],
        }));
        get().triggerSync();
      },
      isLearned: (id) => get().learnedWords.includes(id),

      // ── Bookmarks ──────────────────────────────────────────────────────
      bookmarkedWords: [],
      isBookmarked: (id) => get().bookmarkedWords.includes(id),
      toggleBookmark: (id) => {
        set((state) => ({
          bookmarkedWords: state.bookmarkedWords.includes(id)
            ? state.bookmarkedWords.filter((w) => w !== id)
            : [...state.bookmarkedWords, id],
        }));
        get().triggerSync();
      },

      // ── Stories ────────────────────────────────────────────────────────
      completedStories: [],
      isStoryCompleted: (index) => get().completedStories.includes(index),
      toggleStoryCompleted: (index) => {
        set((state) => ({
          completedStories: state.completedStories.includes(index)
            ? state.completedStories.filter((i) => i !== index)
            : [...state.completedStories, index],
        }));
        get().triggerSync();
      },

      // ── Quiz History & High Scores ─────────────────────────────────────
      quizHistory: [],
      addQuizHistory: (entry) => {
        set((state) => ({ quizHistory: [...state.quizHistory, entry] }));
        get().triggerSync();
      },
      highScores: {},
      updateHighScore: (game, score) => {
        set((state) => ({
          highScores: {
            ...state.highScores,
            [game]: Math.max(state.highScores[game] || 0, score),
          },
        }));
        get().triggerSync();
      },

      // ── Daily Activity ─────────────────────────────────────────────────
      dailyActivity: {},
      recordDailyActivity: (date, words, questions, games) => {
        set((state) => {
          const existing = state.dailyActivity[date] || { wordsLearned: 0, questionsAnswered: 0, gamesPlayed: 0 };
          return {
            dailyActivity: {
              ...state.dailyActivity,
              [date]: {
                wordsLearned: existing.wordsLearned + words,
                questionsAnswered: existing.questionsAnswered + questions,
                gamesPlayed: existing.gamesPlayed + games,
              },
            },
          };
        });
        get().triggerSync();
      },

      // ── Flashcard ─────────────────────────────────────────────────────
      flashcardIndex: 0,
      setFlashcardIndex: (index) => set({ flashcardIndex: index, isFlipped: false }),
      isFlipped: false,
      flip: () => set((state) => ({ isFlipped: !state.isFlipped })),

      // ── Quiz ──────────────────────────────────────────────────────────
      quizScore: 0,
      quizTotal: 0,
      currentQuizQuestion: 0,
      quizQuestions: [],
      startQuiz: (questions) =>
        set({
          quizQuestions: questions,
          quizScore: 0,
          quizTotal: questions.length,
          currentQuizQuestion: 0,
        }),
      answerQuiz: (correct) =>
        set((state) => ({
          quizScore: correct ? state.quizScore + 1 : state.quizScore,
        })),
      resetQuiz: () =>
        set({
          quizScore: 0,
          quizTotal: 0,
          currentQuizQuestion: 0,
          quizQuestions: [],
        }),
      nextQuizQuestion: () =>
        set((state) => ({
          currentQuizQuestion: Math.min(
            state.currentQuizQuestion + 1,
            state.quizQuestions.length - 1,
          ),
        })),

      // ── Memory Game ───────────────────────────────────────────────────
      memoryCards: [],
      memoryMoves: 0,
      memoryPairs: 0,
      memoryLevel: 1,
      setMemoryLevel: (level) => set({ memoryLevel: level }),
      startMemoryGame: (cards) =>
        set({ memoryCards: cards, memoryMoves: 0, memoryPairs: 0 }),
      flipMemoryCard: (id) =>
        set((state) => ({
          memoryCards: state.memoryCards.map((card) =>
            card.id === id ? { ...card } : card,
          ),
        })),
      matchMemoryPair: (id1, id2) =>
        set((state) => ({
          memoryCards: state.memoryCards.map((card) =>
            card.id === id1 || card.id === id2
              ? { ...card, matched: true }
              : card,
          ),
          memoryPairs: state.memoryPairs + 1,
        })),
      incrementMemoryMoves: () =>
        set((state) => ({ memoryMoves: state.memoryMoves + 1 })),
      resetMemoryGame: () =>
        set({ memoryCards: [], memoryMoves: 0, memoryPairs: 0 }),

      // ── Chat ──────────────────────────────────────────────────────────
      chatMessages: [],
      addChatMessage: (msg) =>
        set((state) => ({ chatMessages: [...state.chatMessages, msg] })),
      clearChatMessages: () => set({ chatMessages: [] }),

      // ── Streak ────────────────────────────────────────────────────────
      dailyStreak: 0,
      lastStudyDate: '',
      incrementStreak: () => {
        const today = new Date().toDateString();
        const { lastStudyDate, dailyStreak } = get();
        if (lastStudyDate !== today) {
          const yesterday = new Date();
          yesterday.setDate(yesterday.getDate() - 1);
          if (lastStudyDate === yesterday.toDateString()) {
            set({ dailyStreak: dailyStreak + 1, lastStudyDate: today });
          } else {
            set({ dailyStreak: 1, lastStudyDate: today });
          }
        }
        get().triggerSync();
      },

      // ── SRS (Spaced Repetition System) ────────────────────────────────
      srsCards: {},

      rateWord: (wordId: number, quality: Quality) => {
        const { srsCards } = get();
        const existing = srsCards[wordId] || createSRSCard(wordId);
        const updated = calculateNextReview(existing, quality);
        set({ srsCards: { ...srsCards, [wordId]: updated } });
        get().triggerSync();
      },

      getSRSStats: () => {
        const { srsCards } = get();
        const cards = Object.values(srsCards);
        return {
          total: cards.length,
          new: cards.filter((c) => c.reviewCount === 0).length,
          learning: cards.filter(
            (c) => c.reviewCount > 0 && c.repetitions < 3,
          ).length,
          review: cards.filter(
            (c) => c.repetitions >= 1 && isDueForReview(c),
          ).length,
          mastered: cards.filter(
            (c) => c.repetitions >= 3 && c.easeFactor >= 2.0,
          ).length,
        };
      },

      getDueCardIds: () => {
        const { srsCards } = get();
        return Object.values(srsCards)
          .filter(isDueForReview)
          .map((c) => c.wordId);
      },

      getWeakWordIds: (limit = 20) => {
        const { srsCards } = get();
        return getWeakWordsUtil(Object.values(srsCards), limit);
      },

      getCardDifficulty: (wordId: number) => {
        const { srsCards } = get();
        const card = srsCards[wordId];
        if (!card) return 'new';
        if (card.easeFactor >= 2.0 && card.repetitions >= 3) return 'easy';
        if (card.easeFactor >= 1.5) return 'medium';
        return 'hard';
      },

      // ── Game ──────────────────────────────────────────────────────────
      gameTimer: 0,
      setGameTimer: (t: number) => set({ gameTimer: t }),
      gameDifficulty: 'medium' as const,
      setGameDifficulty: (d: 'easy' | 'medium' | 'hard') =>
        set({ gameDifficulty: d }),
      gameScore: 0,
      setGameScore: (s: number) => set({ gameScore: s }),
      gameStreak: 0,
      setGameStreak: (s: number) => set({ gameStreak: s }),

      // ── Exam ──────────────────────────────────────────────────────────
      examStarted: false,
      examType: null,
      examAnswers: {},
      examScore: 0,
      examTimeRemaining: 0,
      setExamState: (partial) => set(partial as Partial<LearningStore>),
      resetExam: () =>
        set({
          examStarted: false,
          examType: null,
          examAnswers: {},
          examScore: 0,
          examTimeRemaining: 0,
        }),

      // ── Server Sync ───────────────────────────────────────────────────
      isSyncing: false,
      lastSyncedAt: null,
      isLoggedIn: false,
      setIsLoggedIn: (v: boolean) => set({ isLoggedIn: v }),

      triggerSync: () => {
        const { isLoggedIn } = get();
        if (!isLoggedIn) return;

        // Debounce: wait 2 seconds after the last change before syncing
        if (syncTimer) {
          clearTimeout(syncTimer);
        }
        syncTimer = setTimeout(() => {
          get().syncToServer();
        }, 2000);
      },

      syncToServer: async () => {
        const state = get();
        if (state.isSyncing || !state.isLoggedIn) return;

        set({ isSyncing: true });
        try {
          const payload: SyncPayload = {
            learnedWords: state.learnedWords,
            bookmarkedWords: state.bookmarkedWords,
            completedStories: state.completedStories,
            quizHistory: state.quizHistory,
            highScores: state.highScores,
            dailyStreak: state.dailyStreak,
            lastStudyDate: state.lastStudyDate,
            srsCards: state.srsCards,
            dailyActivity: state.dailyActivity,
          };

          const res = await fetch('/api/user/sync', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
          });

          if (res.ok) {
            set({ lastSyncedAt: Date.now() });
          }
        } catch (err) {
          // Silent fail - will retry on next triggerSync
          console.warn('[Store] Sync to server failed:', err);
        } finally {
          set({ isSyncing: false });
        }
      },

      syncFromServer: async () => {
        const state = get();
        if (state.isSyncing || !state.isLoggedIn) return;

        set({ isSyncing: true });
        try {
          const res = await fetch('/api/user/sync');

          if (!res.ok) {
            console.warn('[Store] Failed to fetch server data');
            return;
          }

          const data = await res.json() as {
            dailyStreak: number;
            xp: number;
            lastActiveDate: string;
            profileData: SyncPayload;
          };

          const server = data.profileData;
          const local = get();

          // Merge strategy: union for arrays, max for streak, server wins for most things
          const mergedLearnedWords = [
            ...new Set([
              ...(server.learnedWords || []),
              ...(local.learnedWords || []),
            ]),
          ];

          const mergedBookmarkedWords = [
            ...new Set([
              ...(server.bookmarkedWords || []),
              ...(local.bookmarkedWords || []),
            ]),
          ];

          const mergedCompletedStories = [
            ...new Set([
              ...(server.completedStories || []),
              ...(local.completedStories || []),
            ]),
          ];

          // Take the max streak between server and local
          const mergedStreak = Math.max(
            data.dailyStreak || 0,
            local.dailyStreak || 0,
          );

          // Use server's lastStudyDate if it's more recent
          const serverLastDate = server.lastStudyDate || '';
          const localLastDate = local.lastStudyDate || '';
          const mergedLastStudyDate =
            serverLastDate > localLastDate ? serverLastDate : localLastDate;

          // Merge SRS cards: for each card, take the one with the higher reviewCount
          const mergedSrsCards: Record<number, SRSCard> = {};
          const allCardIds = new Set([
            ...Object.keys(local.srsCards).map(Number),
            ...Object.keys(server.srsCards || {}).map(Number),
          ]);
          for (const cardId of allCardIds) {
            const localCard = local.srsCards[cardId];
            const serverCard = (server.srsCards || {})[String(cardId)] as SRSCard | undefined;
            if (localCard && serverCard) {
              // Take the card with more reviews (more up-to-date)
              mergedSrsCards[cardId] =
                serverCard.reviewCount >= localCard.reviewCount
                  ? serverCard
                  : localCard;
            } else {
              mergedSrsCards[cardId] = localCard || serverCard!;
            }
          }

          // Merge daily activity: sum words/questions/games for each date
          const mergedDailyActivity: Record<string, DailyActivity> = {};
          const allDates = new Set([
            ...Object.keys(local.dailyActivity || {}),
            ...Object.keys(server.dailyActivity || {}),
          ]);
          for (const date of allDates) {
            const localAct = (local.dailyActivity || {})[date] || { wordsLearned: 0, questionsAnswered: 0, gamesPlayed: 0 };
            const serverAct = ((server.dailyActivity || {})[date]) || { wordsLearned: 0, questionsAnswered: 0, gamesPlayed: 0 };
            mergedDailyActivity[date] = {
              wordsLearned: Math.max(localAct.wordsLearned, serverAct.wordsLearned),
              questionsAnswered: Math.max(localAct.questionsAnswered, serverAct.questionsAnswered),
              gamesPlayed: Math.max(localAct.gamesPlayed, serverAct.gamesPlayed),
            };
          }

          // Merge quiz history: union by date+type+score to avoid duplicates
          const existingKeys = new Set(
            local.quizHistory.map((h) => `${h.date}-${h.type}-${h.score}`)
          );
          const mergedQuizHistory = [
            ...local.quizHistory,
            ...((server.quizHistory || []).filter(
              (h: QuizHistoryEntry) => !existingKeys.has(`${h.date}-${h.type}-${h.score}`)
            )),
          ];

          // Merge high scores: take max for each game
          const mergedHighScores = { ...local.highScores };
          for (const [game, score] of Object.entries(server.highScores || {})) {
            mergedHighScores[game] = Math.max(mergedHighScores[game] || 0, score as number);
          }

          set({
            learnedWords: mergedLearnedWords,
            bookmarkedWords: mergedBookmarkedWords,
            completedStories: mergedCompletedStories,
            dailyStreak: mergedStreak,
            lastStudyDate: mergedLastStudyDate,
            srsCards: mergedSrsCards,
            dailyActivity: mergedDailyActivity,
            quizHistory: mergedQuizHistory,
            highScores: mergedHighScores,
            lastSyncedAt: Date.now(),
          });

          console.log('[Store] Synced from server successfully');
        } catch (err) {
          console.warn('[Store] Sync from server failed:', err);
        } finally {
          set({ isSyncing: false });
        }
      },
    }),
    {
      name: 'hsk-learning-storage',
      partialize: (state) => ({
        learnedWords: state.learnedWords,
        bookmarkedWords: state.bookmarkedWords,
        completedStories: state.completedStories,
        quizHistory: state.quizHistory,
        highScores: state.highScores,
        dailyStreak: state.dailyStreak,
        lastStudyDate: state.lastStudyDate,
        srsCards: state.srsCards,
        dailyActivity: state.dailyActivity,
        isLoggedIn: state.isLoggedIn,
      }),
      merge: (persisted, current) => {
        const safe = persisted || {};
        // Never restore currentSection or transient UI state from persisted data
        const {
          currentSection: _ignored,
          isSyncing: _ignored2,
          lastSyncedAt: _ignored3,
          ...restPersisted
        } = safe as Record<string, unknown>;
        void _ignored;
        void _ignored2;
        void _ignored3;
        return { ...current, ...restPersisted };
      },
      onRehydrateStorage: () => {
        return (_state, error) => {
          if (error) console.warn('[Store] Rehydration error:', error);
        };
      },
    },
  ),
);
